/* X for UwU — 单页社交模拟器（全部 AI 走宿主全局 API） */
(function () {
  'use strict';

  var LS = 'xapp_state_v1';
  var VERSION = '1.0.4';
  var MAX_ALT = 8;
  var IMG_REFRESH = 'https://picui.ogmua.cn/s1/2026/10/21/6ad8bbc14e976.webp';
  var IMG_DM = 'https://picui.ogmua.cn/s1/2026/10/21/6ad8bc33b32ad.webp';
  var pendingExpect = {};
  var nickTapAt = 0;

  var state = null;
  var host = { chars: [], wbs: [], personas: [] };
  var igCache = {};
  var busyCount = 0;
  var ui = { view: 'home', tab: 'home', feed: 'foryou', thread: null, profile: null, dm: null };
  var ticking = false;
  var menuTapTimer = null;
  var menuTapTimer = null, menuTapAt = 0;

  /* ============================ 工具 ============================ */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function uid(p) { return (p || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function rnd(a) { return a[Math.floor(Math.random() * a.length)]; }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
  function timeAgo(ts) {
    var now = new Date(), d = new Date(ts);
    var diff = Math.max(0, Date.now() - ts) / 1000;
    if (diff < 60) return '刚刚';
    var sameDay = now.getFullYear() === d.getFullYear() && now.getMonth() === d.getMonth() && now.getDate() === d.getDate();
    if (sameDay) {
      if (diff < 3600) return Math.floor(diff / 60) + '分钟前';
      return Math.floor(diff / 3600) + '小时前';
    }
    var y = new Date(now.getTime() - 86400000);
    if (y.getFullYear() === d.getFullYear() && y.getMonth() === d.getMonth() && y.getDate() === d.getDate()) return '昨天';
    return d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + hhmm(ts);
  }
  function hhmm(ts) { var d = new Date(ts); return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }
  function linkify(text) {
    return esc(text).replace(/(^|\s)(#[^\s#<]{1,30})/g, '$1<span class="ptags">$2</span>');
  }
  function initials(name) {
    var s = String(name || '?').trim();
    return s.slice(0, 1).toUpperCase();
  }
  function avatarFor(name, seed) {
    var colors = ['#1d9bf0', '#7856ff', '#f91880', '#00ba7c', '#ff9800', '#607d8b', '#e0245e', '#17bf63'];
    var c = colors[Math.abs(hash(name + (seed || ''))) % colors.length];
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="96" height="96" rx="48" fill="' + c + '"/><text x="48" y="60" font-size="40" font-family="sans-serif" fill="#fff" text-anchor="middle">' + initials(name) + '</text></svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }
  function hash(s) { var h = 0; s = String(s); for (var i = 0; i < s.length; i++) { h = ((h << 5) - h + s.charCodeAt(i)) | 0; } return h; }
  function slug(name) {
    var s = String(name || '').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 12);
    return s || ('x' + Math.random().toString(36).slice(2, 7));
  }
  function uniqHandle(base, exclude) {
    var b = slug(base), h = b, i = 1;
    while (Object.values(state.accounts).some(function (a) { return a.handle === h && a.id !== exclude; })) { h = b + (++i); }
    return h;
  }

  var I = {
    /* 底栏「首页」的旧版图标（内联 SVG，24×24 视口）。
       1.0.4 起底栏改用 FontAwesome solid/house 图片（见 botnav()），
       这份保留备查，想回退时把 botnav 里的首页那一行换回 navBtn('home', I.home, 0) 即可。 */
    home: '<svg viewBox="0 0 24 24"><path d="M12 2 2 11h3v10h5v-6h4v6h5V11h3z"/></svg>',
    bell: '<svg viewBox="0 0 24 24"><path d="M12 22a2.5 2.5 0 0 0 2.5-2.5h-5A2.5 2.5 0 0 0 12 22zm7-6V11a7 7 0 0 0-5-6.7V3a2 2 0 1 0-4 0v1.3A7 7 0 0 0 5 11v5l-2 2v1h18v-1z"/></svg>',
    mail: '<svg viewBox="0 0 24 24"><path d="M3 5h18v14H3zm2 2.4V17h14V7.4l-7 4.6zm0-1.4 7 4.6 7-4.6z"/></svg>',
    user: '<svg viewBox="0 0 24 24"><path d="M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0 2c-4.4 0-8 2.2-8 5v2h16v-2c0-2.8-3.6-5-8-5z"/></svg>',
    reply: '<svg viewBox="0 0 24 24"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 9.6 9.6 0 0 1-3.8-.8L3 21l1.9-4.6A8.4 8.4 0 0 1 12 3a8.4 8.4 0 0 1 9 8.5z"/></svg>',
    repost: '<svg viewBox="0 0 24 24"><path d="M7 7h10v3l4-4-4-4v3H5v6h2zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2z"/></svg>',
    like: '<svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-9.5-9A5.3 5.3 0 0 1 12 6.5 5.3 5.3 0 0 1 21.5 12c-2 4.4-9.5 9-9.5 9z"/></svg>',
    views: '<svg viewBox="0 0 24 24"><path d="M4 20V10h4v10zm6 0V4h4v16zm6 0v-7h4v7z"/></svg>',
    share: '<svg viewBox="0 0 24 24"><path d="M14 9V5l7 7-7 7v-4H4V9z"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M20 11H7.8l5.6-5.6L12 4l-8 8 8 8 1.4-1.4L7.8 13H20z"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7 7 17"/></svg>',
    more: '<svg viewBox="0 0 24 24"><path d="M6 12a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm8 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm8 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm9 4-2.1-.7a7 7 0 0 0-.7-1.7l1-2-1.8-1.8-2 1a7 7 0 0 0-1.7-.7L13 3h-2l-.7 2.1a7 7 0 0 0-1.7.7l-2-1L4.8 6.6l1 2a7 7 0 0 0-.7 1.7L3 11v2l2.1.7a7 7 0 0 0 .7 1.7l-1 2 1.8 1.8 2-1a7 7 0 0 0 1.7.7L11 21h2l.7-2.1a7 7 0 0 0 1.7-.7l2 1 1.8-1.8-1-2a7 7 0 0 0 .7-1.7L21 13z"/></svg>',
    refresh: '<svg viewBox="0 0 24 24"><path d="M17.7 6.3A8 8 0 1 0 20 12h-2a6 6 0 1 1-1.8-4.3L12 12h9V3z"/></svg>',
    moon: '<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 9 9 7 7 0 0 1-9-9z"/></svg>',
    sun: '<svg viewBox="0 0 24 24"><path d="M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM2 11h3v2H2zm17 0h3v2h-3zM11 2h2v3h-2zm0 17h2v3h-2zM4.9 4.9 7 7 5.6 8.4 3.5 6.3zm12.2 12.2 2.1 2.1-1.4 1.4-2.1-2.1zM19.1 4.9l1.4 1.4L18.4 8.4 17 7zM3.5 17.7l2.1-2.1L7 17l-2.1 2.1z"/></svg>',
    lock: '<svg viewBox="0 0 24 24"><path d="M17 9V7a5 5 0 0 0-10 0v2H5v12h14V9zm-8-2a3 3 0 0 1 6 0v2H9z"/></svg>',
    menu: '<svg viewBox="0 0 24 24"><path d="M4 7h14v2H4zm0 4h14v2H4zm0 4h10v2H4z"/></svg>'
  };

  function svg(icon, cls) { return '<span class="' + (cls || '') + '">' + icon + '</span>'; }
  function imgIcon(src, cls) { return '<img class="' + (cls || 'icon-img') + '" src="' + esc(src) + '" alt="">'; }

  /* ============================ 存储 ============================ */
  function freshSocial() {
    return { interests: [], posts: [], following: [], followers: [], blocked: [], dms: {}, notifs: [], affinity: {}, pending: [], npcFile: {} };
  }
  function freshState() {
    return {
      v: 2, theme: 'light', activeUserId: null, accounts: {}, social: {},
      charState: {}, avatars: [], createdAt: Date.now(),
      settings: { allWorldBooks: true, worldBookIds: [], sleepStart: 23, sleepEnd: 8, replyDelay: true, cheer: true, autoFollowBack: true }
    };
  }
  function loadState() {
    try {
      var raw = localStorage.getItem(LS);
      if (!raw) return freshState();
      var s = JSON.parse(raw);
      var d = freshState();
      s.settings = Object.assign(d.settings, s.settings || {});
      s.settings.allWorldBooks = true;
      s.settings.worldBookIds = [];
      s.accounts = s.accounts || {};
      s.social = s.social || {};
      s.charState = s.charState || {};
      s.avatars = s.avatars || [];
      // 旧版的“秘密设定”统一迁移为“发帖偏好”
      Object.keys(s.accounts).forEach(function (id) {
        var a = s.accounts[id];
        if (a && !a.pref && a.secret) a.pref = a.secret;
      });
      // v2：白色模式作为默认主题；仅第一次升级时切换，之后尊重用户手动选择
      if (!s.v || s.v < 2) { s.theme = 'light'; s.v = 2; }
      return s;
    } catch (e) { return freshState(); }
  }
  function save() {
    try { localStorage.setItem(LS, JSON.stringify(state)); }
    catch (e) { toast('存储空间不足，头像库可能过大'); }
  }
  function S() {
    var id = state.activeUserId;
    if (!id) return freshSocial();
    if (!state.social[id]) state.social[id] = freshSocial();
    var s = state.social[id];
    ['interests', 'posts', 'following', 'followers', 'blocked', 'notifs', 'pending'].forEach(function (k) { if (!Array.isArray(s[k])) s[k] = []; });
    if (!s.dms) s.dms = {};
    if (!s.affinity) s.affinity = {};
    if (!s.npcFile) s.npcFile = {};
    return s;
  }
  function A(id) { return state.accounts[id] || null; }
  function activeUser() { return A(state.activeUserId); }
  function isMine(a) { return a && a.kind === 'user' && a.id === state.activeUserId; }

  /* ============================ 宿主桥接 ============================ */
  function bridgeOk() { return !!(window.UwU && typeof UwU.callAI === 'function'); }
  function setBusy(on) {
    busyCount = Math.max(0, busyCount + (on ? 1 : -1));
    var bar = $('#progress');
    if (!bar) {
      bar = document.createElement('div'); bar.id = 'progress'; bar.className = 'progress'; document.body.appendChild(bar);
    }
    bar.className = 'progress' + (busyCount ? ' on' : '');
  }
  function toast(t) {
    var old = $('#toast'); if (old) old.remove();
    var el = document.createElement('div'); el.id = 'toast'; el.className = 'toast'; el.textContent = String(t);
    document.body.appendChild(el);
    setTimeout(function () { if (el.parentNode) el.remove(); }, 2400);
  }
  async function ask(system, user, opts) {
    if (!bridgeOk()) throw new Error('桥接不可用：请在 UwU 小手机的 store 中打开本应用');
    setBusy(true);
    try {
      var res = await UwU.callAI([
        { role: 'system', content: system },
        { role: 'user', content: user }
      ], { temperature: (opts && typeof opts.temperature === 'number') ? opts.temperature : 0.95 });
      return String(res == null ? '' : res).trim();
    } finally { setBusy(false); }
  }
  function extractJSON(text) {
    if (!text) return null;
    var s = String(text).trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    try { return JSON.parse(s); } catch (e) { }
    var a = s.indexOf('{'), b = s.lastIndexOf('}');
    if (a >= 0 && b > a) { try { return JSON.parse(s.slice(a, b + 1)); } catch (e) { } }
    var c = s.indexOf('['), d = s.lastIndexOf(']');
    if (c >= 0 && d > c) { try { return JSON.parse(s.slice(c, d + 1)); } catch (e) { } }
    return null;
  }
  async function loadHost() {
    if (!bridgeOk()) throw new Error('桥接不可用');
    host.chars = (await UwU.getCharacters()) || [];
    try { host.wbs = (await UwU.getWorldBooks()) || []; } catch (e) { host.wbs = []; }
    try { host.personas = (await UwU.getUserPersonas()) || []; } catch (e) { host.personas = []; }
  }

  /* ============================ 账号体系 ============================ */
  function upsertUser() {
    if (state.activeUserId && A(state.activeUserId)) return;
    var p = host.personas.find(function (x) { return x.isActive; }) || host.personas[0] || null;
    var firstChar = host.chars[0] || null;
    var name = (p && p.name) || (firstChar && firstChar.myName) || '我';
    var av = (p && p.avatar) || (firstChar && firstChar.myAvatar) || avatarFor(name);
    var id = 'u_' + Math.random().toString(36).slice(2, 8);
    state.accounts[id] = {
      id: id, kind: 'user', name: name, handle: uniqHandle(name === '我' ? 'me' : name),
      avatar: av, bio: '只是在 X 上看看。', createdAt: Date.now()
    };
    state.activeUserId = id;
    S();
    save();
  }
  function ensureCharAccounts() {
    host.chars.forEach(function (c) {
      var cid = String(c.id);
      var st = state.charState[cid] || { enabled: true, mainId: null, defaultId: null, alts: [], knownUserIds: [] };
      st.knownUserIds = Array.isArray(st.knownUserIds) ? st.knownUserIds : [];
      var baseName = c.remarkName || c.realName || c.name || 'Char';
      if (!st.mainId || !A(st.mainId)) {
        var mid = 'cm_' + cid.replace(/[^\w-]/g, '').slice(0, 10) + '_' + Math.random().toString(36).slice(2, 5);
        state.accounts[mid] = {
          id: mid, kind: 'char', charId: cid, altType: 'main', ownerUserId: null,
          name: baseName, handle: uniqHandle(baseName), avatar: c.avatar || avatarFor(baseName),
          bio: '',
          persona: '', secret: '', protected: true, tags: [], createdAt: Date.now()
        };
        st.mainId = mid;
      }
      if (!st.defaultId || !A(st.defaultId)) {
        var did = 'ca_' + cid.replace(/[^\w-]/g, '').slice(0, 10) + '_d';
        if (!A(did)) {
          var dn = baseName + '·小号';
          state.accounts[did] = {
            id: did, kind: 'char', charId: cid, altType: 'default', ownerUserId: null,
            name: dn, handle: uniqHandle(baseName + 'alt'), avatar: avatarFor(dn, cid),
            bio: '', persona: '',
            secret: '', protected: true, tags: [], createdAt: Date.now()
          };
        }
        st.defaultId = did;
      }
      // 旧版本会自动把人设摘要/默认文案写进 char 简介；升级后清空，用户手动改过的简介保留
      var mainAcc = A(st.mainId), defAcc = A(st.defaultId);
      var autoBio = String(c.persona || '').replace(/\s+/g, ' ').slice(0, 70) || '——';
      if (mainAcc && (mainAcc.bio === autoBio || mainAcc.bio === '——')) mainAcc.bio = '';
      if (defAcc && defAcc.bio === '小号，随便发点。') defAcc.bio = '';
      st.alts = (st.alts || []).filter(function (id) { return A(id); });
      state.charState[cid] = st;
    });
    save();
  }
  function charAccounts(cid, uidOnly) {
    var st = state.charState[String(cid)];
    if (!st) return [];
    var ids = [st.mainId, st.defaultId].concat(st.alts || []).filter(Boolean);
    return ids.map(A).filter(function (a) {
      if (!a) return false;
      if (uidOnly && a.ownerUserId && a.ownerUserId !== state.activeUserId) return false;
      return true;
    });
  }
  function canSee(a) {
    if (!a) return false;
    if (a.kind === 'cheer') return false;
    if (a.kind === 'user') return a.id === state.activeUserId;
    if (a.kind === 'char') {
      var st = state.charState[String(a.charId)];
      if (st && st.enabled === false) return false;
    }
    if (a.ownerUserId && a.ownerUserId !== state.activeUserId) return false;
    return true;
  }
  function visibleAccounts(kind) {
    return Object.values(state.accounts).filter(function (a) { return canSee(a) && (!kind || a.kind === kind); });
  }
  function charOf(a) {
    if (!a || !a.charId) return null;
    return host.chars.find(function (c) { return String(c.id) === String(a.charId); }) || null;
  }
  function personaOf(a) {
    if (!a) return '';
    var c = charOf(a);
    if (c && a.kind === 'char' && (a.altType === 'main' || a.altType === 'default')) {
      var live = String(c.persona || '');
      if (a.altType === 'default') {
        var base = c.remarkName || c.realName || a.name;
        return '这是' + base + '在X上的默认分身（表面是小号，内里是同一人格，共享记忆与IG身份）。\n' + live;
      }
      return live;
    }
    return a.persona || (c ? String(c.persona || '') : '');
  }
  function prefOf(a) {
    if (!a) return '';
    return String(a.pref || a.secret || '');
  }
  function knowsUserX(acc) {
    if (!acc) return true;
    if (acc.kind !== 'char') return true;
    var st = state.charState[String(acc.charId)] || {};
    return (st.knownUserIds || []).indexOf(state.activeUserId) >= 0 || (acc.knownUserIds || []).indexOf(state.activeUserId) >= 0;
  }
  function markKnownUser(acc) {
    if (!acc || acc.kind !== 'char') return;
    var st = state.charState[String(acc.charId)];
    if (!st) return;
    st.knownUserIds = st.knownUserIds || [];
    if (st.knownUserIds.indexOf(state.activeUserId) < 0) {
      st.knownUserIds.push(state.activeUserId);
      save();
    }
  }
  function relation(accId) {
    var s = S();
    return {
      following: s.following.indexOf(accId) >= 0,
      follower: s.followers.indexOf(accId) >= 0,
      blocked: s.blocked.indexOf(accId) >= 0,
      affinity: clamp(s.affinity[accId] || 0, 0, 100)
    };
  }
  function addAffinity(accId, n) {
    var s = S();
    s.affinity[accId] = clamp((s.affinity[accId] || 0) + n, 0, 100);
  }
  function relLabel(n) {
    if (n >= 90) return '灵魂共鸣';
    if (n >= 75) return '很亲密';
    if (n >= 55) return '密友';
    if (n >= 35) return '朋友';
    if (n >= 15) return '眼熟';
    return '陌生';
  }
  function pushNotif(n) {
    var s = S();
    s.notifs.unshift(Object.assign({ id: uid('n'), ts: Date.now(), read: false }, n));
    if (s.notifs.length > 120) s.notifs.length = 120;
  }
  function unreadNotifs() { return S().notifs.filter(function (n) { return !n.read; }).length; }
  function unreadDMs() {
    var n = 0, s = S();
    Object.keys(s.dms).forEach(function (k) {
      (s.dms[k] || []).forEach(function (m) { if (m.from !== 'me' && !m.read) n++; });
    });
    return n;
  }

  /* ============================ 世界书 / 上下文 ============================ */
  function wbText(limit) {
    var list = (host.wbs || []).filter(function (w) { return w && w.type === 'entry'; });
    var t = list.map(function (w) { return '【' + (w.name || '') + '】' + String(w.content || '').slice(0, 420); }).join('\n');
    return (t || '（无）').slice(0, limit || 3200);
  }
  function userText(charId, acc) {
    var u = activeUser();
    var p = '';
    if (charId) {
      var c = host.chars.find(function (x) { return String(x.id) === String(charId); });
      if (c && c.myPersona) p = String(c.myPersona);
    }
    if (!p) {
      var ap = (host.personas || []).find(function (x) { return x.isActive; }) || (host.personas || [])[0];
      if (ap) p = String(ap.persona || '');
    }
    var known = acc ? knowsUserX(acc) : true;
    return '昵称：' + u.name + (known ? '（@' + u.handle + '）' : '（X账号未告知）') +
      (known ? '' : '\n注意：TA不知道用户的X账号，禁止提及、猜测、@ 或表现得知用户的账号；除非用户主动告诉TA。') +
      (p ? '\n用户人设：' + String(p).slice(0, 600) : '');
  }
  async function igText(a) {
    var c = charOf(a); if (!c) return '';
    var key = String(c.id);
    if (igCache[key] && Date.now() - igCache[key].t < 120000) return igCache[key].v;
    try {
      var h = await UwU.getChatHistory(c.id, 18);
      var nm = c.remarkName || c.realName || 'TA';
      var v = (h || []).map(function (m) {
        return (m.role === 'user' ? '我' : nm) + '：' + String(m.content || '').replace(/\s+/g, ' ').slice(0, 160);
      }).join('\n');
      igCache[key] = { t: Date.now(), v: v };
      return v;
    } catch (e) { return ''; }
  }
  function relText(a) {
    var r = relation(a.id);
    return '关注：' + (r.following ? '我关注了TA' : '未关注') + '；' + (r.follower ? 'TA关注我（互关）' : 'TA未关注我') +
      '；亲密度' + r.affinity + '/100（' + relLabel(r.affinity) + '）';
  }
  function xMemory(acc) {
    var c = charOf(acc); if (!c) return '';
    var s = S(), parts = [];
    charAccounts(c.id, true).forEach(function (a) {
      if (a.id === acc.id) return;
      var th = s.dms[a.id] || [];
      if (th.length) {
        parts.push('『' + a.name + '』的私信：\n' + th.slice(-6).map(function (m) {
          return (m.from === 'me' ? '我' : a.name) + '：' + m.text;
        }).join('\n'));
      }
    });
    charAccounts(c.id, true).forEach(function (a) {
      if (a.id === acc.id) return;
      var ps = s.posts.filter(function (p) { return p.authorId === a.id; }).slice(0, 2);
      if (ps.length) parts.push('『' + a.name + '』最近的动态：' + ps.map(function (p) { return p.text; }).join(' / '));
    });
    return parts.join('\n').slice(0, 1200);
  }
  function personaBlock(a) {
    var c = charOf(a);
    var main = c ? String(c.persona || '').slice(0, 900) : '';
    var pref = prefOf(a).slice(0, 900);
    var lines = [];
    lines.push('X账号：' + a.name + ' @' + a.handle + (a.bio ? ' | 简介：' + a.bio : ''));
    lines.push('X人设（35%权重，只作底色）：' + String(personaOf(a)).slice(0, 900));
    if (pref) lines.push('发帖偏好（65%权重，决定线上发什么、用什么语气与尺度）：' + pref);
    if (a.kind === 'char') lines.push('线上状态：网络上的TA比现实中更大胆、更直接，敢发现实中不会说的念头；但仍保持同一人格底色。');
    if (a.altType && a.altType !== 'main' && a.altType !== 'default' && main) lines.push('主人格（IG上的TA，别直接照搬）：' + main);
    if (a.kind === 'npc') lines.push('身份：X上的普通用户/可发展NPC，没有小号。可以说外语；若说外语，同时给出自然中文翻译。');
    return lines.join('\n');
  }
  var SYS = '你是社交平台 X 的模拟引擎，根据角色设定生成真实、有网感的内容。规则：不要旁白和解说，不要用引号包住整条内容，不替用户做决定。角色的X发言以「发帖偏好」为主（约65%），现实人设只作底色（约35%）；线上比线下更大胆、更放得开。';

  /* ============================ AI 生成 ============================ */
  async function genPosts(accounts) {
    if (!accounts.length) return [];
    var lines = accounts.map(function (a) {
      return '- id:' + a.id + ' | ' + a.name + ' @' + a.handle + ' | 类型：' + (a.kind === 'npc' ? 'NPC（可说外语）' : '角色') +
        ' | X人设35%：' + String(personaOf(a)).replace(/\s+/g, ' ').slice(0, 150) +
        ' | 发帖偏好65%：' + String(prefOf(a)).replace(/\s+/g, ' ').slice(0, 200);
    });
    var ig = await igText(accounts[0]);
    var user = '【世界书】\n' + wbText() + '\n\n【用户】' + userText(accounts[0].charId, accounts[0]) +
      '\n\n【关系】\n' + accounts.map(function (a) { return a.name + '：' + relText(a); }).join('\n') +
      (ig ? '\n\n【最近IG聊天（只用来理解关系语气，不要复述）】\n' + ig.slice(0, 1200) : '') +
      '\n\n为以下X账号各生成1条新动态（≤110字，可带情绪、生活细节、emoji、#话题）：\n' + lines.join('\n') +
      '\n\n硬性要求：每条动态约65%来自「发帖偏好」（话题、语气、尺度、表达欲），约35%保留X人设底色；角色在线上比现实中更大胆。' +
      '\nNPC若使用外语：text 写原文，lang 写语言名（如 英语/日语/法语），zh 写自然的中文翻译；角色或中文动态则 lang 留空、zh 与 text 相同。' +
      '\n\n只返回JSON：{"posts":[{"id":"账号id","text":"正文","lang":"语言或空","zh":"中文翻译或正文"}]}';
    var raw = await ask(SYS, user);
    var data = extractJSON(raw);
    var out = [];
    if (data && Array.isArray(data.posts)) {
      data.posts.forEach(function (p) {
        var acc = accounts.find(function (a) { return a.id === p.id; }) || accounts.find(function (a) { return a.handle === p.handle; });
        if (acc && p.text) out.push({ acc: acc, text: String(p.text).slice(0, 400), lang: acc.kind === 'npc' ? String(p.lang || '').slice(0, 10) : '', zh: acc.kind === 'npc' ? String(p.zh || '').slice(0, 400) : '' });
      });
    }
    if (!out.length && raw) out.push({ acc: accounts[0], text: raw.replace(/^["'“]|["'”]$/g, '').slice(0, 300), lang: '', zh: '' });
    return out;
  }

  async function genNew() {
    var interests = S().interests;
    var tags = [];
    state.avatars.forEach(function (a) { (a.tags || []).forEach(function (t) { if (tags.indexOf(t) < 0) tags.push(t); }); });
    var charsBrief = host.chars.filter(function (c) { return (state.charState[String(c.id)] || {}).enabled !== false; })
      .slice(0, 8).map(function (c) { return '- id:' + c.id + ' | ' + (c.remarkName || c.realName); }).join('\n');
    var user = '【世界书】\n' + wbText(2000) + '\n\n【用户】' + userText() +
      '\n【用户兴趣关键词】' + (interests.join('、') || '（无）') +
      '\n【可用头像标签】' + (tags.join('、') || '（无）') +
      '\n\n请生成1-2个X上的新用户（可发展为朋友/暧昧/恋人/树洞等），每人一条动态；NPC 可以说外语，此时 post 写原文并给 postLang（语言名）与 postZh（中文翻译）。' +
      (charsBrief ? '\n并有约30%概率额外生成其中一个角色的小号（charAlt，可为null），风格与主人格不同：\n' + charsBrief : '\ncharAlt固定为null。') +
      '\n\n只返回JSON：{"npcs":[{"name":"网名","handle":"英文handle","bio":"简介","persona":"性格与说话方式","tags":["头像标签"],"post":"第一条动态","postLang":"语言或空","postZh":"中文翻译或原文"}],"charAlt":{"charId":"上方id","name":"小号名","handle":"handle","bio":"简介","persona":"这个小号的人设","post":"动态"}或null}';
    var raw = await ask(SYS, user, { temperature: 1.0 });
    var data = extractJSON(raw);
    if (!data) throw new Error('AI 返回格式无法解析');
    var out = { npcs: [], alt: null };
    (data.npcs || []).slice(0, 2).forEach(function (n) {
      if (!n || !n.name) return;
      var av = pickAvatar(n.tags);
      var id = 'np_' + Math.random().toString(36).slice(2, 8);
      state.accounts[id] = {
        id: id, kind: 'npc', charId: null, ownerUserId: state.activeUserId,
        name: String(n.name).slice(0, 20), handle: uniqHandle(n.handle || n.name),
        avatar: av, bio: String(n.bio || '').slice(0, 90), persona: String(n.persona || '').slice(0, 900),
        secret: '', protected: false, tags: Array.isArray(n.tags) ? n.tags.slice(0, 5) : [], createdAt: Date.now(),
        knownUserIds: [state.activeUserId]
      };
      S().npcFile[id] = { inFile: false, relationship: '陌生', note: '' };
      out.npcs.push(id);
      if (n.post) addPost(id, String(n.post).slice(0, 400), { lang: String(n.postLang || '').slice(0, 10), zh: String(n.postZh || '').slice(0, 400) });
    });
    if (data.charAlt && data.charAlt.name && data.charAlt.charId) {
      var c = host.chars.find(function (x) { return String(x.id) === String(data.charAlt.charId); });
      if (c) {
        var st = state.charState[String(c.id)];
        if (st && (st.alts || []).length < MAX_ALT) {
          var aid = 'ca_' + String(c.id).replace(/[^\w-]/g, '').slice(0, 8) + '_' + Math.random().toString(36).slice(2, 6);
          state.accounts[aid] = {
            id: aid, kind: 'char', charId: String(c.id), altType: 'extra', ownerUserId: state.activeUserId,
            name: String(data.charAlt.name).slice(0, 20), handle: uniqHandle(data.charAlt.handle || data.charAlt.name),
            avatar: pickAvatar(data.charAlt.tags) || avatarFor(data.charAlt.name, aid),
            bio: String(data.charAlt.bio || '').slice(0, 90), persona: String(data.charAlt.persona || '').slice(0, 900),
            pref: '', secret: '', protected: false, tags: [], createdAt: Date.now()
          };
          st.alts.push(aid);
          out.alt = aid;
          if (data.charAlt.post) addPost(aid, String(data.charAlt.post).slice(0, 400));
        }
      }
    }
    save();
    return out;
  }

  function pickAvatar(tags) {
    if (!state.avatars.length) return null;
    var arr = state.avatars;
    if (Array.isArray(tags) && tags.length) {
      var hit = arr.filter(function (a) { return (a.tags || []).some(function (t) { return tags.indexOf(t) >= 0; }); });
      if (hit.length) arr = hit;
    }
    return rnd(arr).data;
  }

  async function genCommentReply(post, comment, accArg) {
    var acc = accArg || A(post.authorId); if (!acc) throw new Error('作者不存在');
    var ig = await igText(acc), xm = xMemory(acc);
    var isNpc = acc.kind === 'npc';
    var user = '【世界书】\n' + wbText(1600) + '\n\n【角色】\n' + personaBlock(acc) +
      '\n\n【用户】' + userText(acc.charId, acc) + '\n【关系】' + relText(acc) +
      (ig ? '\n【最近IG聊天（参考语气）】\n' + ig.slice(0, 700) : '') +
      (xm ? '\n【TA其他X账号的记忆（大小号认知互通）】\n' + xm : '') +
      '\n\n【TA的帖子】@' + acc.handle + '：' + post.text +
      '\n【要回复的内容】' + comment.name + '：' + comment.text +
      '\n\n请以' + acc.name + '的身份引用/回应上面这句话，1-2句，符合TA的人设、发帖偏好与关系；可自然引用其中一小句（用「」括起），但不要整段复读，不要解释。' +
      (isNpc ? '\nNPC可以说外语：reply 写原文，lang 写语言名（如 英语/日语），zh 写中文翻译；中文则 lang 留空、zh 与 reply 相同。只返回JSON：{"reply":"回复正文","lang":"语言或空","zh":"中文翻译或正文"}' : '\n只输出回复正文。');
    var raw = await ask(SYS, user, { temperature: 0.9 });
    if (isNpc) {
      var data = extractJSON(raw);
      if (data && data.reply) return { text: String(data.reply).slice(0, 400), lang: String(data.lang || '').slice(0, 10), zh: String(data.zh || '').slice(0, 400) };
    }
    return { text: String(raw || '').slice(0, 400), lang: '', zh: '' };
  }

  async function genDMReply(acc) {
    var s = S(), thread = s.dms[acc.id] || [];
    var hist = thread.slice(-14).map(function (m) { return (m.from === 'me' ? '我' : acc.name) + '：' + m.text; }).join('\n');
    var ig = await igText(acc), xm = xMemory(acc);
    var user = '【世界书】\n' + wbText(1600) + '\n\n【角色】\n' + personaBlock(acc) +
      '\n\n【用户】' + userText(acc.charId, acc) + '\n【关系】' + relText(acc) +
      (ig ? '\n【IG聊天（同一段关系的记忆，参考）】\n' + ig.slice(0, 900) : '') +
      (xm ? '\n【TA其他X账号的记忆（大小号认知互通）】\n' + xm : '') +
      '\n\n【X私信记录】\n' + hist +
      '\n\n请以' + acc.name + '的身份回复最后一条私信。1-3句，符合人设、发帖偏好与亲密度，可以分多行发多条。只输出回复内容。';
    return await ask(SYS, user, { temperature: 0.95 });
  }

  async function genAltPersona(char, hint, pref) {
    var c = char;
    var user = '【世界书】\n' + wbText(1500) +
      '\n\n【主人格】' + (c.remarkName || c.realName) + '：' + String(c.persona || '').slice(0, 1200) +
      '\n\n【用户】' + userText(c.id) +
      (pref ? '\n【这个小号的发帖偏好】' + pref : '') +
      '\n\n请为这个角色设计一个X小号（方向：' + (hint || '与主人格反差较大的隐藏账号') + '）。小号是独立人格，但共享记忆。' +
      '\n只返回JSON：{"name":"小号网名","handle":"英文handle","bio":"简介","persona":"小号人设与说话方式"}';
    var raw = await ask(SYS, user, { temperature: 1.0 });
    var data = extractJSON(raw);
    if (!data) throw new Error('生成失败');
    return data;
  }

  async function genReveal(acc) {
    var c = charOf(acc);
    var user = '【世界书】\n' + wbText(1200) + '\n\n【小号】\n' + personaBlock(acc) +
      '\n\n【主人格】' + (c ? String(c.persona || '').slice(0, 800) : '') +
      '\n\n【用户】' + userText(acc.charId, acc) + '\n【关系】' + relText(acc) +
      '\n\n情境：用户把自己的IG账号ID发给了这个小号。' +
      (c ? '这个小号其实就是' + (c.remarkName || c.realName) + '，而用户和TA在IG上认识。' : '') +
      '\n请生成TA看到后的反应，可能装傻、逗弄、试探或坦白，2-3条短消息。' +
      '\n只返回JSON：{"messages":["第一条","第二条"]}';
    var raw = await ask(SYS, user, { temperature: 1.0 });
    var data = extractJSON(raw);
    return (data && Array.isArray(data.messages)) ? data.messages.slice(0, 3).map(String) : [raw];
  }

  /* ============================ 帖子 ============================ */
  function addPost(authorId, text, extra) {
    var s = S();
    var p = {
      id: uid('p'), authorId: authorId, text: String(text || '').slice(0, 600),
      lang: (extra && extra.lang) || '', zh: (extra && extra.zh) || '',
      ts: Date.now(), likes: [], reposts: [], comments: [],
      views: 20 + Math.floor(Math.random() * 200), cheerLikes: 0, baseLikes: 0,
      cheer: !!(extra && extra.cheer)
    };
    s.posts.unshift(p);
    if (s.posts.length > 300) s.posts.length = 300;
    save();
    return p;
  }
  function postById(id) { return S().posts.find(function (p) { return p.id === id; }) || null; }
  function feedPosts(feed) {
    var s = S(), arr = s.posts.filter(function (p) { return s.blocked.indexOf(p.authorId) < 0 && canSee(A(p.authorId)); });
    if (feed === 'following') {
      arr = arr.filter(function (p) { return s.following.indexOf(p.authorId) >= 0 || p.authorId === state.activeUserId; });
      arr.sort(function (a, b) { return b.ts - a.ts; });
    } else {
      arr = arr.slice().sort(function (a, b) { return scorePost(b) - scorePost(a); });
    }
    return arr;
  }
  function scorePost(p) {
    var s = S(), sc = p.ts / 1e12;
    if (s.following.indexOf(p.authorId) >= 0) sc += 25;
    var txt = String(p.text || '').toLowerCase();
    s.interests.forEach(function (k) { if (k && txt.indexOf(String(k).toLowerCase()) >= 0) sc += 10; });
    var a = A(p.authorId);
    if (a && a.ownerUserId === state.activeUserId) sc += 6;
    if (a && a.kind === 'npc') sc += 4;
    return sc;
  }
  function likeCount(p) { return (p.likes || []).length + (p.cheerLikes || 0) + (p.baseLikes || 0); }

  /* ============================ 关注 / 拉黑 ============================ */
  function follow(accId, silent) {
    var s = S(), a = A(accId);
    if (!a || s.following.indexOf(accId) >= 0) return;
    s.following.push(accId);
    addAffinity(accId, 1);
    save();
    if (!silent) toast('已关注 @' + a.handle);
    setTimeout(function () { maybeFollowBack(accId); }, 3000 + Math.random() * 5000);
    render();
  }
  function unfollow(accId) {
    var s = S(), i = s.following.indexOf(accId);
    if (i >= 0) s.following.splice(i, 1);
    save(); render();
  }
  function maybeFollowBack(accId) {
    if (!state.settings.autoFollowBack) return;
    var s = S(), a = A(accId);
    if (!a || s.blocked.indexOf(accId) >= 0) return;
    if (s.following.indexOf(accId) < 0) return;
    if (s.followers.indexOf(accId) >= 0) return;
    var aff = s.affinity[accId] || 0;
    var chance = a.kind === 'npc' ? (aff >= 40 ? 0.75 : aff >= 20 ? 0.5 : 0.22) : (aff >= 60 ? 0.5 : aff >= 35 ? 0.25 : 0.06);
    if (/高冷|冷淡|疏离|傲娇|不近人情/.test(personaOf(a))) chance *= 0.55;
    if (Math.random() >= chance) return;
    s.followers.push(accId);
    pushNotif({ type: 'follow', accountId: accId, text: '@' + a.handle + ' 回关了你' });
    save();
    toast('@' + a.handle + ' 回关了你');
    if (a.kind === 'npc' && Math.random() < 0.45) setTimeout(function () { npcHi(accId); }, 4000 + Math.random() * 4000);
    if (ui.view === 'profile' && ui.profile === accId) render();
  }
  function block(accId) {
    var s = S(), a = A(accId);
    if (!a) return;
    if (s.blocked.indexOf(accId) < 0) s.blocked.push(accId);
    s.following = s.following.filter(function (x) { return x !== accId; });
    s.followers = s.followers.filter(function (x) { return x !== accId; });
    s.pending = s.pending.filter(function (p) { return p.accId !== accId; });
    save();
    toast('已拉黑 @' + a.handle);
    ui.view = 'home'; render();
  }
  function unblock(accId) {
    var s = S();
    s.blocked = s.blocked.filter(function (x) { return x !== accId; });
    save(); render();
  }

  /* ============================ 休眠 / 延时 ============================ */
  function isSleeping() {
    if (!state.settings.replyDelay) return false;
    var st = Number(state.settings.sleepStart), en = Number(state.settings.sleepEnd);
    if (st === en) return false;
    var d = new Date(), h = d.getHours() + d.getMinutes() / 60;
    return st < en ? (h >= st && h < en) : (h >= st || h < en);
  }
  function nextWakeTs() {
    var en = Number(state.settings.sleepEnd);
    var d = new Date(); var w = new Date(d);
    w.setHours(en, 0, 0, 0);
    if (w.getTime() <= Date.now()) w.setDate(w.getDate() + 1);
    return w.getTime();
  }
  function schedule(kind, payload) {
    var s = S();
    var wake = nextWakeTs() + (5 + Math.floor(Math.random() * 25)) * 60000;
    s.pending.push(Object.assign({ id: uid('t'), kind: kind, dueAt: wake, ts: Date.now() }, payload));
    save();
    var d = new Date(wake);
    toast('TA 可能已休息，回复会在 ' + d.getHours() + ':' + ('0' + d.getMinutes()).slice(-2) + ' 后出现');
  }
  async function processPending() {
    if (ticking) return;
    ticking = true;
    var changed = false;
    try {
      var s = S();
      var due = s.pending.filter(function (p) { return p.dueAt <= Date.now(); }).slice(0, 2);
      for (var i = 0; i < due.length; i++) {
        var t = due[i];
        var idx = s.pending.indexOf(t); if (idx >= 0) s.pending.splice(idx, 1);
        save();
        try {
          if (t.kind === 'comment') {
            var post = postById(t.postId), acc = A(t.accId);
            if (!post || !acc) continue;
            var rep = await genCommentReply(post, { name: t.name, text: t.text, id: t.commentId }, acc);
            addComment(post.id, acc.id, rep.text, { quote: { id: t.commentId, name: t.name, text: t.text }, lang: rep.lang, zh: rep.zh });
            addAffinity(acc.id, 2);
            pushNotif({ type: 'comment', accountId: acc.id, postId: post.id, text: acc.name + ' 回复了你的评论：' + (rep.zh || rep.text).slice(0, 40) });
            changed = true;
          } else if (t.kind === 'dm') {
            var acc2 = A(t.accId);
            if (!acc2) continue;
            var reply = await genDMReply(acc2);
            pushDM(acc2.id, 'them', reply, false);
            addAffinity(acc2.id, 2);
            pushNotif({ type: 'dm', accountId: acc2.id, text: acc2.name + ' 给你发了私信' });
            changed = true;
          }
        } catch (e) { console.error('[X] pending failed', e); }
      }
    } finally {
      ticking = false;
      if (changed) { save(); if (ui.view === 'home' || ui.view === 'messages' || ui.view === 'dm' || ui.view === 'thread') render(); }
    }
  }

  /* ============================ 评论 ============================ */
  function addComment(postId, authorId, text, meta) {
    var p = postById(postId); if (!p) return null;
    var m = meta || {};
    var c = {
      id: uid('c'), authorId: authorId || null, name: m.name || (A(authorId) ? A(authorId).name : '匿名'),
      text: String(text || '').slice(0, 400), ts: Date.now(), cheer: !!m.cheer,
      quoteId: m.quote ? m.quote.id : '', quoteName: m.quote ? m.quote.name : '', quoteText: m.quote ? m.quote.text : '',
      lang: m.lang || '', zh: m.zh || ''
    };
    p.comments.push(c); save();
    return c;
  }
  function commentAsMe(postId, text) {
    var u = activeUser();
    var c = addComment(postId, u.id, text, {});
    var post = postById(postId);
    var addr = A(post.authorId);
    if (addr && addr.id !== state.activeUserId) addAffinity(addr.id, 2);
    save(); render();
    return c;
  }
  function toggleLike(postId) {
    var p = postById(postId); if (!p) return;
    var i = p.likes.indexOf('me');
    if (i >= 0) p.likes.splice(i, 1);
    else { p.likes.push('me'); if (p.authorId !== state.activeUserId) addAffinity(p.authorId, 1); }
    save();
    var el = $('[data-act="like"][data-id="' + postId + '"]');
    if (el) {
      el.classList.toggle('liked', i < 0);
      var n = el.querySelector('span:last-child'); if (n) n.textContent = likeCount(p);
    } else render();
  }
  function toggleRepost(postId) {
    var p = postById(postId); if (!p) return;
    p.reposts = p.reposts || [];
    var i = p.reposts.indexOf('me');
    if (i >= 0) p.reposts.splice(i, 1); else p.reposts.push('me');
    addAffinity(p.authorId, 1);
    save(); render();
  }

  function alreadyQuoted(post, cid) {
    return post.comments.some(function (c) { return c.quoteId === cid; });
  }
  function pickReplyAccount(post) {
    var s = S();
    var pool = visibleAccounts().filter(function (a) {
      return a.id !== state.activeUserId && (a.kind === 'char' || a.kind === 'npc') && s.blocked.indexOf(a.id) < 0;
    });
    if (!pool.length) return null;
    pool = shuffle(pool);
    pool.sort(function (a, b) {
      var wa = (s.following.indexOf(a.id) >= 0 ? 2 : 0) + (s.followers.indexOf(a.id) >= 0 ? 2 : 0) + (s.affinity[a.id] || 0) / 50 + (a.kind === 'char' ? 1 : 0);
      var wb = (s.following.indexOf(b.id) >= 0 ? 2 : 0) + (s.followers.indexOf(b.id) >= 0 ? 2 : 0) + (s.affinity[b.id] || 0) / 50 + (b.kind === 'char' ? 1 : 0);
      return wb - wa;
    });
    return pool[0];
  }
  async function expectCommentReply(postId, commentId) {
    var post = postById(postId); if (!post) return;
    var c = post.comments.find(function (x) { return x.id === commentId; });
    if (!c) return;
    var acc = A(post.authorId);
    if (!acc || acc.id === state.activeUserId) return;
    if (alreadyQuoted(post, c.id)) return toast('TA已经回复过这条啦');
    if (pendingExpect[c.id]) return;
    pendingExpect[c.id] = true;
    var btn = $('[data-act="expect-reply"][data-id="' + c.id + '"]');
    if (btn) btn.textContent = '等待TA回复…';
    try {
      var rep = await genCommentReply(post, { id: c.id, name: c.name, text: c.text }, acc);
      addComment(post.id, acc.id, rep.text, { quote: { id: c.id, name: c.name, text: c.text }, lang: rep.lang, zh: rep.zh });
      addAffinity(acc.id, 2);
      pushNotif({ type: 'comment', accountId: acc.id, postId: post.id, text: acc.name + ' 回复了你的评论：' + (rep.zh || rep.text).slice(0, 40) });
      save();
    } catch (e) { toast('回复失败：' + e.message); }
    delete pendingExpect[c.id];
    render();
  }
  async function expectPost(postId) {
    var post = postById(postId); if (!post) return;
    var key = 'post_' + postId;
    if (pendingExpect[key]) return;
    var acc = pickReplyAccount(post);
    if (!acc) return toast('还没有能回复的 char 或 NPC');
    pendingExpect[key] = true;
    setBusy(true);
    try {
      var u = activeUser();
      var rep = await genCommentReply(post, { id: post.id, name: u.name, text: post.text }, acc);
      addComment(post.id, acc.id, rep.text, { quote: { id: post.id, name: u.name, text: post.text }, lang: rep.lang, zh: rep.zh });
      addAffinity(acc.id, 3);
      var shown = rep.zh || rep.text;
      pushNotif({ type: 'comment', accountId: acc.id, postId: post.id, text: acc.name + ' 回复了你的帖子：' + shown.slice(0, 40) });
      if (Math.random() < 0.72) {
        post.likes = post.likes || [];
        if (post.likes.indexOf(acc.id) < 0) post.likes.push(acc.id);
        pushNotif({ type: 'like', accountId: acc.id, postId: post.id, text: acc.name + ' 点赞了你的帖子' });
      }
      save();
      toast(acc.name + ' 回复了你' + (post.likes.indexOf(acc.id) >= 0 ? '，还点了赞' : ''));
      render();
    } catch (e) { toast('生成失败：' + e.message); }
    delete pendingExpect[key];
    setBusy(false);
  }
  function deletePost(postId) {
    S().posts = S().posts.filter(function (p) { return p.id !== postId; });
    if (ui.thread === postId) { ui.thread = null; ui.view = 'home'; ui.tab = 'home'; }
    save(); closeLayer(); render();
    toast('帖子已删除');
  }

  /* ============================ 发帖 / 捧场 ============================ */
  var CHEER_NAMES = ['路过的风', '今天也想摸鱼', '柠檬不加冰', '夜猫子', '一只小透明', 'momo', '咖啡续命', '星星收集者', '早八人', '偷偷看世界'];
  var CHEER_TEXTS = ['笑死，太真实了', '好会写', '蹲一个后续', '啊啊啊好甜', '路过点个赞', '同款心情', '说得太对了', '羡慕了', '这条我先收藏', '抱抱你'];
  function cheerPost(postId) {
    if (!state.settings.cheer) return;
    var p = postById(postId); if (!p) return;
    p.cheerLikes = (p.cheerLikes || 0) + 1 + Math.floor(Math.random() * 4);
    if (Math.random() < 0.45) {
      var name = rnd(CHEER_NAMES) + Math.floor(Math.random() * 90 + 10);
      addComment(postId, null, rnd(CHEER_TEXTS), { name: name, cheer: true });
    }
    save();
    if (ui.view === 'home' || ui.view === 'thread') render();
  }
  async function publishPost(text) {
    text = String(text || '').trim();
    if (!text) return toast('写下点什么吧');
    var p = addPost(state.activeUserId, text);
    ui.view = 'home'; ui.feed = 'foryou'; closeLayer();
    render();
    toast('已发布');
    if (state.settings.cheer) setTimeout(function () { cheerPost(p.id); }, 1200 + Math.random() * 1500);
    setTimeout(function () { proactiveDm(p); }, 4000 + Math.random() * 4000);
  }
  async function proactiveDm(post) {
    var s = S();
    var npcs = visibleAccounts('npc').filter(function (a) { return s.blocked.indexOf(a.id) < 0; });
    var cand = npcs.filter(function (a) { return s.followers.indexOf(a.id) >= 0 || s.following.indexOf(a.id) >= 0 || (s.affinity[a.id] || 0) >= 20; });
    if (!cand.length || Math.random() > 0.45) return;
    var acc = rnd(cand);
    if ((s.dms[acc.id] || []).length > 0 && Math.random() > 0.5) return;
    try {
      var user = '【世界书】\n' + wbText(1200) + '\n【角色】\n' + personaBlock(acc) + '\n【用户】' + userText(acc.charId, acc) + '\n【关系】' + relText(acc) +
        '\n\n情境：用户刚发布了动态「' + String(post.text).slice(0, 200) + '」。请以TA身份主动发一条X私信搭话（可以评论那条动态、约聊或分享日常）。1-2句，只输出内容。';
      var txt = await ask(SYS, user, { temperature: 0.95 });
      if (!(S().dms[acc.id] || []).length) S().dms[acc.id] = [];
      pushDM(acc.id, 'them', txt, false);
      pushNotif({ type: 'dm', accountId: acc.id, text: acc.name + ' 主动给你发了私信' });
      addAffinity(acc.id, 1);
      save();
      if (ui.view === 'messages' || ui.view === 'dm') render();
    } catch (e) { }
  }

  async function npcHi(accId) {
    var s = S(), acc = A(accId);
    if (!acc || acc.kind !== 'npc' || s.blocked.indexOf(accId) >= 0) return;
    if ((s.dms[accId] || []).length) return;
    var user = '【世界书】\n' + wbText(1200) + '\n【角色】\n' + personaBlock(acc) +
      '\n【用户】' + userText(acc.charId, acc) + '\n【关系】' + relText(acc) +
      '\n\n情境：TA刚回关了用户，想主动发第一条X私信认识一下。1-2句，符合人设。只输出内容。';
    try {
      var txt = await ask(SYS, user, { temperature: 0.95 });
      pushDM(acc.id, 'them', txt, false);
      pushNotif({ type: 'dm', accountId: acc.id, text: acc.name + ' 主动给你发了私信' });
      addAffinity(acc.id, 2); save();
      if (ui.view === 'messages') render();
    } catch (e) { }
  }

  /* ============================ 私信 ============================ */
  function pushDM(accId, from, text, read) {
    var s = S();
    if (!s.dms[accId]) s.dms[accId] = [];
    var parts = String(text || '').split(/\n+/).map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 3);
    if (!parts.length) parts = ['……'];
    parts.forEach(function (t) {
      s.dms[accId].push({ id: uid('m'), from: from, text: t.slice(0, 500), ts: Date.now(), read: from === 'me' ? true : !!read });
    });
    save();
  }
  function openDm(accId) {
    var a = A(accId); if (!a) return;
    var s = S();
    if (!s.dms[accId]) s.dms[accId] = [];
    s.dms[accId].forEach(function (m) { m.read = true; });
    save();
    ui.view = 'dm'; ui.dm = accId; render();
    setTimeout(scrollDm, 60);
  }
  function scrollDm() {
    var el = $('#dmBody'); if (el) el.scrollTop = el.scrollHeight;
  }
  function sendDm(text) {
    text = String(text || '').trim(); if (!text) return;
    var acc = A(ui.dm); if (!acc) return;
    pushDM(acc.id, 'me', text, true);
    addAffinity(acc.id, 2);
    var u = activeUser();
    if (acc.kind === 'char' && u && (text.indexOf('@' + u.handle) >= 0 || text.indexOf(u.handle) >= 0)) markKnownUser(acc);
    save(); render(); setTimeout(scrollDm, 40);
  }
  async function refreshDm(accId) {
    var acc = A(accId); if (!acc) return;
    var s = S(), thread = s.dms[accId] || [];
    if (!thread.length) return toast('先给TA发条消息吧');
    if (thread[thread.length - 1].from !== 'me') return toast('TA已经回复过啦');
    var key = 'dm_' + accId;
    if (pendingExpect[key]) return;
    pendingExpect[key] = true;
    try {
      var txt = await genDMReply(acc);
      if (!txt) throw new Error('没有生成内容');
      pushDM(acc.id, 'them', txt, true);
      addAffinity(acc.id, 2);
      pushNotif({ type: 'dm', accountId: acc.id, text: acc.name + ' 回复了你的私信' });
      save(); render(); setTimeout(scrollDm, 60);
    } catch (e) { toast('回复失败：' + e.message); }
    delete pendingExpect[key];
  }
  function tellX(accId) {
    var acc = A(accId); if (!acc) return;
    var u = activeUser();
    pushDM(acc.id, 'me', '我的X账号是 @' + u.handle, true);
    markKnownUser(acc);
    save(); closeLayer();
    if (ui.view === 'dm' && ui.dm === acc.id) { render(); setTimeout(scrollDm, 50); }
    toast('已告诉TA你的 X 账号');
  }
  async function giveIg(accId) {
    var acc = A(accId); if (!acc) return;
    var s = S(), u = activeUser();
    if (s.npcFile[acc.id] && s.npcFile[acc.id].igGiven) return toast('已经给过啦');
    pushDM(acc.id, 'me', '我的IG是：' + (u.name || 'me') + '（就是这个名字）', true);
    if (acc.kind === 'npc') {
      var prev = s.npcFile[acc.id] || {};
      s.npcFile[acc.id] = Object.assign({ note: '' }, prev, {
        igGiven: true, inFile: true,
        relationship: prev.relationship && prev.relationship !== '陌生' ? prev.relationship : 'IG好友'
      });
      var aff = s.affinity[acc.id] || 0;
      var re = aff >= 40 ? '好呀，我马上加你。' : '收到，我去搜搜看。';
      pushDM(acc.id, 'them', re, true);
      pushNotif({ type: 'follow', accountId: acc.id, text: acc.name + ' 通过了你的IG好友申请' });
      addAffinity(acc.id, 5);
      toast('TA 的档案已进入 File');
    } else if (acc.altType === 'main') {
      var rep = '';
      try { rep = await genDMReply(acc); } catch (e) { }
      pushDM(acc.id, 'them', rep || '我本来就有你的IG啊。', true);
      addAffinity(acc.id, 3);
      pushNotif({ type: 'dm', accountId: acc.id, text: acc.name + ' 收到了你的IG ID' });
    } else {
      var msgs = ['……', '你确定要给我这个？'];
      try { msgs = await genReveal(acc); } catch (e) { }
      msgs.forEach(function (m) { pushDM(acc.id, 'them', m, true); });
      acc.revealed = true;
      pushNotif({ type: 'dm', accountId: acc.id, text: acc.name + ' 收到了你的IG ID' });
    }
    save(); render(); setTimeout(scrollDm, 60);
  }

  /* ============================ 刷新动态 ============================ */
  async function refreshKnown() {
    var s = S();
    var pool = visibleAccounts().filter(function (a) { return (a.kind === 'char' || a.kind === 'npc') && s.blocked.indexOf(a.id) < 0; });
    if (!pool.length) return toast('还没有可刷新的角色，先点「认识新人」');
    var followed = pool.filter(function (a) { return s.following.indexOf(a.id) >= 0; });
    var pick = shuffle(followed.length ? followed : pool).slice(0, 3);
    toast('正在刷新动态…');
    try {
      var items = await genPosts(pick);
      items.forEach(function (it) { addPost(it.acc.id, it.text, { lang: it.lang, zh: it.zh }); });
      save(); render();
      toast('看到 ' + items.length + ' 条新动态');
    } catch (e) { toast('刷新失败：' + e.message); }
  }
  async function refreshNew() {
    toast('正在认识新人…');
    try {
      var out = await genNew();
      save(); render();
      var n = out.npcs.length + (out.alt ? 1 : 0);
      toast(n ? ('认识了 ' + n + ' 个新账号') : '暂时没有新人出现');
    } catch (e) { toast('失败：' + e.message); }
  }

  /* ============================ 渲染基础 ============================ */
  function render() {
    document.documentElement.dataset.theme = state.theme;
    var app = $('#app');
    if (!state.activeUserId || !activeUser()) { app.innerHTML = '<div class="empty">正在准备账号…</div>'; return; }
    switch (ui.view) {
      case 'thread': renderThread(); break;
      case 'notifs': renderNotifs(); break;
      case 'messages': renderMessages(); break;
      case 'dm': renderDm(); break;
      case 'profile': renderProfile(); break;
      case 'settings': renderSettings(); break;
      case 'chars': renderChars(); break;
      case 'avatars': renderAvatars(); break;
      case 'worldbook': renderWorldBook(); break;
      case 'npcs': renderNpcFile(); break;
      default: renderHome();
    }
  }
  function go(view, patch) {
    ui.view = view;
    if (patch) Object.keys(patch).forEach(function (k) { ui[k] = patch[k]; });
    render();
    var sc = $('#feedScroll'); if (sc) sc.scrollTop = 0;
  }
  function head(title, opts) {
    opts = opts || {};
    return '<div class="xhead">' +
      (opts.back ? '<button class="iconbtn" data-act="back">' + I.back + '</button>' : '') +
      '<div class="ttl">' + esc(title) + '</div><div class="spacer"></div>' +
      (opts.html || '') + '</div>';
  }
  function navBtn(tab, icon, badge) {
    return '<button class="nv ' + (ui.tab === tab ? 'active' : '') + '" data-act="nav" data-v="' + tab + '">' +
      icon + (badge ? '<span class="bdg">' + (badge > 99 ? '99+' : badge) + '</span>' : '') + '</button>';
  }
  function botnav() {
    // ===== 底栏三项：首页 / 私信 / 我的 =====
    // [首页] 当前：FontAwesome solid/house 图片（30×30，深色模式反色）
    //   上一版代码（内联 SVG，保留备查）：
    //     navBtn('home', I.home, 0)
    // [私信] 当前：FontAwesome 信封（CSS mask，30×30，跟随底栏配色）
    //   上一版代码：
    //     navBtn('messages', imgIcon(IMG_DM, 'nav-img'), unreadDMs())   // 1.0.1
    //     navBtn('messages', I.mail, unreadDMs())                        // 1.0.1 之前
    // [我的] 当前：FontAwesome regular/user 图片（30×30，深色模式反色）
    //   上一版代码：
    //     navBtn('profile', I.user, 0)
    return '<nav class="bottomnav">' +
      navBtn('home', '<img class="nav-img-icon" src="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/svgs/solid/house.svg" width="30" height="30" alt="主页">', 0) +
      navBtn('messages', '<span class="nav-icon-envelope"></span>', unreadDMs()) +
      navBtn('profile', '<img class="nav-img-icon" src="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/svgs/regular/user.svg" width="30" height="30" alt="我的">', 0) +
      '</nav>';
  }
  function av(a, cls) {
    var src = (a && a.avatar) || avatarFor(a && a.name);
    return '<img class="avatar ' + (cls || 'av40') + '" src="' + esc(src) + '" alt="">';
  }
  function openProfileBtn(a, cls) {
    return '<button data-act="open-profile" data-id="' + a.id + '">' + av(a, cls) + '</button>';
  }

  /* ============================ 首页 ============================ */
  function homeHead() {
    return '<div class="xhead">' +
      '<button class="iconbtn" data-act="open-drawer" title="菜单">' + I.menu + '</button>' +
      '<div class="spacer"></div><div class="logo">X</div><div class="spacer"></div>' +
      '<button class="iconbtn" data-act="refresh-sheet" title="刷新动态">' + imgIcon(IMG_REFRESH, 'head-img') + '</button>' +
      '</div>';
  }
  function feedTabs() {
    return '<div class="tabs">' +
      '<button class="tab ' + (ui.feed === 'foryou' ? 'active' : '') + '" data-act="feed" data-v="foryou">For you</button>' +
      '<button class="tab ' + (ui.feed === 'following' ? 'active' : '') + '" data-act="feed" data-v="following">Following</button>' +
      '</div>';
  }
  function emptyFeed() {
    return '<div class="empty">这里还很安静。</div>';
  }
  function renderHome() {
    var posts = feedPosts(ui.feed);
    $('#app').innerHTML = homeHead() + feedTabs() +
      '<div class="scroll" id="feedScroll">' + (posts.length ? posts.map(function (p) { return postCard(p); }).join('') : emptyFeed()) + '</div>' +
      '<button class="fab" data-act="compose" title="发帖">' + I.plus + '</button>' + botnav();
  }

  /* ============================ 帖子卡片 ============================ */
  function postCard(p, big) {
    var a = A(p.authorId) || { id: '', name: '已注销', handle: 'deleted', avatar: avatarFor('?') };
    var s = S();
    var liked = p.likes.indexOf('me') >= 0;
    var reposted = (p.reposts || []).indexOf('me') >= 0;
    var kindBadge = a.kind === 'char' && a.altType !== 'main'
      ? '<span class="badge gray">小号</span>'
      : a.kind === 'npc' ? '<span class="badge gray">new</span>' : '';
    var following = s.following.indexOf(a.id) >= 0;
    var shown = (p.lang && p.zh) ? p.zh : p.text;
    var trans = (p.lang && p.zh) ? '<div class="trans">由「' + esc(p.lang) + '」翻译</div>' : '';
    return '<article class="post" data-act="open-post" data-id="' + p.id + '">' +
      '<div data-act="open-profile" data-id="' + a.id + '">' + av(a, 'av40') + '</div>' +
      '<div class="body">' +
      '<div class="prow">' +
      '<b class="pname" data-act="open-profile" data-id="' + a.id + '">' + esc(a.name) + '</b>' + kindBadge +
      '<span class="phandle">@' + esc(a.handle) + (following ? ' · 已关注' : '') + '</span>' +
      '<span class="ptime">· ' + timeAgo(p.ts) + '</span>' +
      '<button class="pmenu" data-act="post-menu" data-id="' + p.id + '">' + I.more + '</button>' +
      '</div>' +
      trans + '<div class="ptext' + (big ? ' small' : '') + '">' + linkify(shown) + '</div>' +
      '<div class="pactions">' +
      '<button class="pa" data-act="open-post" data-id="' + p.id + '">' + I.reply + '<span>' + p.comments.length + '</span></button>' +
      '<button class="pa ' + (reposted ? 'reposted' : '') + '" data-act="repost" data-id="' + p.id + '">' + I.repost + '<span>' + (p.reposts || []).length + '</span></button>' +
      '<button class="pa ' + (liked ? 'liked' : '') + '" data-act="like" data-id="' + p.id + '">' + I.like + '<span>' + likeCount(p) + '</span></button>' +
      '<span class="pa">' + I.views + '<span>' + (p.views || 0) + '</span></span>' +
      '<button class="pa" data-act="share" data-id="' + p.id + '">' + I.share + '</button>' +
      '</div></div></article>';
  }
  function commentRow(c, post) {
    var a = c.authorId ? A(c.authorId) : null;
    var name = c.name || (a ? a.name : '匿名');
    var avSrc = a ? av(a, 'av36') : '<span class="avatar av36" style="display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--muted)">' + esc(initials(name)) + '</span>';
    var clickable = a && canSee(a);
    var mine = c.authorId === state.activeUserId;
    var pa = A(post.authorId);
    var canExpect = mine && !c.cheer && pa && pa.id !== state.activeUserId && (pa.kind === 'char' || pa.kind === 'npc') && !alreadyQuoted(post, c.id);
    var shown = (c.lang && c.zh) ? c.zh : c.text;
    var trans = (c.lang && c.zh) ? '<div class="trans">由「' + esc(c.lang) + '」翻译</div>' : '';
    var quote = c.quoteText ? '<div class="quote">' + (c.quoteName ? '<b>' + esc(c.quoteName) + '：</b>' : '') + esc(String(c.quoteText).slice(0, 100)) + '</div>' : '';
    return '<div class="cmt' + (mine ? ' mine' : '') + '">' +
      (clickable ? '<button data-act="open-profile" data-id="' + a.id + '">' + avSrc + '</button>' : avSrc) +
      '<div class="body"><div class="prow"><b class="pname">' + esc(name) + '</b>' +
      (c.cheer ? '<span class="badge gray">路人</span>' : '') +
      '<span class="ptime">· ' + timeAgo(c.ts) + '</span></div>' +
      quote + trans +
      '<div class="ptext" style="font-size:14px">' + linkify(shown) + '</div>' +
      (canExpect ? '<button class="expect-btn" data-act="expect-reply" data-id="' + c.id + '" data-post="' + post.id + '">期待TA回复</button>' : '') +
      '</div></div>';
  }
  function renderThread() {
    var p = postById(ui.thread);
    if (!p) { ui.view = 'home'; return renderHome(); }
    var a = A(p.authorId);
    var comments = p.comments.slice().sort(function (x, y) { return x.ts - y.ts; });
    $('#app').innerHTML = head('帖子', { back: true }) +
      '<div class="scroll" id="feedScroll">' +
      postCard(p, true) +
      '<div class="pad row" style="border-bottom:1px solid var(--border)">' +
      '<textarea id="cmtInput" placeholder="发布你的回复…" rows="2" style="flex:1;background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:8px 10px;outline:none;resize:none"></textarea>' +
      '<button class="btn sm" data-act="comment-send" data-id="' + p.id + '">回复</button></div>' +
      (comments.length ? comments.map(function (c) { return commentRow(c, p); }).join('') : '<div class="empty">还没有回复，来当第一个。</div>') +
      '</div>';
  }

  /* ============================ 通知 ============================ */
  function renderNotifs() {
    var s = S(), list = s.notifs;
    list.forEach(function (n) { n.read = true; });
    save();
    $('#app').innerHTML = head('通知', {
      back: true,
      html: list.length ? '<button class="iconbtn" data-act="clear-notifs" title="清空">' + I.close + '</button>' : ''
    }) +
      '<div class="scroll">' + (list.length ? list.map(function (n) {
        var a = A(n.accountId);
        var icon = n.type === 'dm' ? I.mail : n.type === 'follow' ? I.user : n.type === 'like' ? I.like : I.reply;
        return '<div class="item" data-act="' + (n.postId ? 'open-post' : n.type === 'dm' ? 'open-dm' : 'open-profile') + '" data-id="' + (n.postId || n.accountId) + '">' +
          (a ? av(a, 'av36') : '<span class="avatar av36"></span>') +
          '<div class="t"><div>' + esc(n.text) + '</div><div class="sub">' + timeAgo(n.ts) + '</div></div>' +
          '<span class="muted">' + icon + '</span></div>';
      }).join('') : '<div class="empty">还没有通知。<br>发帖、关注或私信后会出现在这里。</div>') + '</div>' + botnav();
  }

  /* ============================ 私信列表 ============================ */
  function renderMessages() {
    var s = S();
    var rows = Object.keys(s.dms).map(function (id) {
      var a = A(id); if (!a || s.blocked.indexOf(id) >= 0) return null;
      var msgs = s.dms[id]; if (!msgs || !msgs.length) return null;
      var last = msgs[msgs.length - 1];
      var unread = msgs.filter(function (m) { return m.from !== 'me' && !m.read; }).length;
      return { a: a, last: last, unread: unread, ts: last.ts };
    }).filter(Boolean).sort(function (x, y) { return y.ts - x.ts; });
    $('#app').innerHTML = head('私信', { html: '<button class="iconbtn" data-act="new-dm" title="新私信">' + I.plus + '</button>' }) +
      '<div class="scroll">' + (rows.length ? rows.map(function (r) {
        return '<button class="dmrow" data-act="open-dm" data-id="' + r.a.id + '">' + av(r.a, 'av48') +
          '<div class="t"><div class="nm">' + esc(r.a.name) + (r.unread ? '<span class="badge">' + r.unread + '</span>' : '') + '</div>' +
          '<div class="last">' + (r.last.from === 'me' ? '我：' : '') + esc(r.last.text) + '</div></div>' +
          '<span class="small muted">' + timeAgo(r.ts) + '</span></button>';
      }).join('') : '<div class="empty">还没有私信。<br>去某个人的主页点「私信」，或等 NPC 主动找你。</div>') + '</div>' + botnav();
  }

  /* ============================ 私信会话 ============================ */
  function renderDm() {
    var a = A(ui.dm); if (!a) { ui.view = 'messages'; return renderMessages(); }
    var s = S(), msgs = s.dms[a.id] || [];
    msgs.forEach(function (m) { m.read = true; });
    var rel = relation(a.id);
    $('#app').innerHTML = '<div class="dmhead">' +
      '<button class="iconbtn" data-act="back">' + I.back + '</button>' +
      '<button data-act="open-profile" data-id="' + a.id + '">' + av(a, 'av36') + '</button>' +
      '<div style="flex:1;min-width:0"><div class="nm">' + esc(a.name) + '</div><div class="hd">@' + esc(a.handle) + (rel.follower ? ' · 关注了你' : '') + ' · 亲密度 ' + rel.affinity + '</div></div>' +
      '<button class="iconbtn" data-act="dm-menu" data-id="' + a.id + '">' + I.more + '</button></div>' +
      '<div class="dm-body" id="dmBody">' +
      (msgs.length ? msgs.map(function (m) {
        return '<div class="bubble ' + (m.from === 'me' ? 'me' : 'them') + '">' + esc(m.text) + '</div>';
      }).join('') : '<div class="empty">还没有聊天记录。<br>打个招呼吧。</div>') +
      '</div>' +
      '<div class="dm-input"><textarea id="dmInput" rows="1" placeholder="发消息…"></textarea>' +
      '<button class="send" data-act="dm-send">' + I.share + '</button>' +
      '<button class="send refresh" data-act="dm-refresh" data-id="' + a.id + '" title="刷新回复">' + imgIcon(IMG_REFRESH, 'refresh-img') + '</button></div>';
    setTimeout(scrollDm, 50);
  }

  /* ============================ 个人主页 ============================ */
  function renderProfile() {
    var id = ui.profile || state.activeUserId;
    var a = A(id);
    if (!a) { ui.view = 'home'; return renderHome(); }
    var me = a.id === state.activeUserId;
    var s = S(), rel = relation(a.id);
    var posts = s.posts.filter(function (p) { return p.authorId === a.id; }).sort(function (x, y) { return y.ts - x.ts; });
    var followed = s.following.indexOf(a.id) >= 0;
    var altChips = '';
    if (a.kind === 'char') {
      var c = charOf(a);
      if (c) {
        var alts = charAccounts(c.id, true).filter(function (x) { return x.id !== a.id; });
        if (alts.length) {
          altChips = '<div class="chips" style="padding:10px 14px 0">' + alts.map(function (x) {
            return '<button class="chip" data-act="open-profile" data-id="' + x.id + '">@' + esc(x.handle) + (x.altType === 'default' ? ' · 默认分身' : ' · 小号') + '</button>';
          }).join('') + '</div>';
        }
      }
    }
    var meta = '';
    if (me) {
      meta = '<div class="profile-meta"><span><b>' + s.following.length + '</b> 正在关注</span><span><b>' + s.followers.length + '</b> 关注者</span><span><b>' + posts.length + '</b> 动态</span></div>';
    } else {
      meta = '<div class="profile-meta"><span>亲密度 <b>' + rel.affinity + '</b>/100 · ' + relLabel(rel.affinity) + '</span>' +
        (rel.following && rel.follower ? '<span class="badge gray">互关</span>' : '') + '</div>';
    }
    var actions = me ? '' : '<div class="profile-actions">' +
      '<button class="btn sm ' + (followed ? 'ghost' : '') + '" data-act="' + (followed ? 'unfollow' : 'follow') + '" data-id="' + a.id + '">' + (followed ? '已关注' : '关注') + '</button>' +
      '<button class="btn sm ghost" data-act="open-dm" data-id="' + a.id + '">私信</button>' +
      '</div>';
    var coverStyle = a.cover ? ' style="background-image:url(\'' + esc(a.cover) + '\')"' : '';
    $('#app').innerHTML = head(me ? '' : a.name, {
      back: !me,
      html: me ? ''
        : '<button class="iconbtn" data-act="dm-menu" data-id="' + a.id + '">' + I.more + '</button>'
    }) +
      '<div class="scroll">' +
      '<div class="profile-head"><div class="pcover"' + coverStyle + '></div>' +
      '<div class="profile-top">' + av(a, 'av72') + '</div>' +
      '<div class="profile-name"' + (me ? ' data-act="nick-edit" title="双击昵称编辑资料"' : '') + '>' + esc(a.name) + (a.kind === 'npc' ? '<span class="badge gray" style="margin-left:6px">npc</span>' : '') + '</div>' +
      '<div class="profile-handle">@' + esc(a.handle) + '</div>' +
      (a.bio ? '<div class="profile-bio">' + esc(a.bio) + '</div>' : '') + meta +
      (a.kind === 'npc' && s.npcFile[a.id] && s.npcFile[a.id].inFile ? '<div class="small muted mt8">已在 File 中 · ' + esc(s.npcFile[a.id].relationship || '') + '</div>' : '') +
      actions +
      '</div>' + altChips +
      '<div class="tabs ptabs"><div class="tab active">动态</div></div>' +
      (posts.length ? posts.map(function (p) { return postCard(p); }).join('') : '<div class="empty">还没有发过动态。</div>') +
      '</div>' + botnav();
  }

  /* ============================ 设置 ============================ */
  function itemRow(opts) {
    return '<button class="item" data-act="' + opts.act + '"' + (opts.id ? ' data-id="' + opts.id + '"' : '') + '>' +
      (opts.icon || '') +
      '<span class="t"><span>' + esc(opts.title) + '</span>' + (opts.sub ? '<span class="sub">' + esc(opts.sub) + '</span>' : '') + '</span>' +
      (opts.right || '<span class="chev">›</span>') + '</button>';
  }
  function renderSettings() {
    var s = S();
    $('#app').innerHTML = head('设置', { back: true }) +
      '<div class="scroll settings-scroll">' +
      '<div class="settings-ttl">外观</div><div class="card">' +
      '<div class="item"><span class="t"><span>深色模式</span><span class="sub">黑白两套主题</span></span>' +
      '<button class="toggle ' + (state.theme === 'dark' ? 'on' : '') + '" data-act="theme-toggle"></button></div>' +
      '</div>' +
      '<div class="settings-ttl">兴趣偏好（只影响当前账号）</div><div class="card">' +
      '<div class="chips">' + (s.interests.length ? s.interests.map(function (k) {
        return '<span class="chip">' + esc(k) + '<button class="x" data-act="del-interest" data-id="' + esc(k) + '">×</button></span>';
      }).join('') : '<span class="muted small">还没有关键词，添加后会改变 For you 推送和新 NPC 人设</span>') + '</div>' +
      '<div class="row" style="padding:6px 14px 12px"><input id="interestInput" placeholder="添加关键词，如：乐队、猫、悬疑" style="flex:1;background:var(--panel2);border:1px solid var(--border);border-radius:10px;padding:8px 10px;outline:none">' +
      '<button class="btn sm" data-act="add-interest">添加</button></div></div>' +
      '<div style="height:20px"></div></div>';
  }

  /* ============================ 角色管理 + 黑名单 ============================ */
  function renderChars() {
    var s = S();
    var blocked = s.blocked.map(A).filter(Boolean);
    var html = head('角色与黑名单', { back: true, html: '<button class="iconbtn" data-act="resync" title="同步宿主数据">' + I.refresh + '</button>' }) +
      '<div class="scroll settings-scroll">' +
      '<div class="pad small muted">已同步宿主角色数据 · 每个 char 必有一个大号和一个默认分身；额外小号最多 ' + MAX_ALT + ' 个。</div>';
    if (!host.chars.length) html += '<div class="empty">宿主里还没有角色。<br>先去 404 创建或导入一个角色。</div>';
    host.chars.forEach(function (c) {
      var st = state.charState[String(c.id)] || {};
      var enabled = st.enabled !== false;
      var main = A(st.mainId), def = A(st.defaultId);
      var alts = (st.alts || []).map(A).filter(Boolean);
      html += '<div class="card"><div class="item">' +
        av(main || { name: c.remarkName || c.realName, avatar: c.avatar }, 'av36') +
        '<span class="t"><span>' + esc(c.remarkName || c.realName || '角色') + '</span><span class="sub">' + (enabled ? '已接入 X' : '未接入') + ' · ' + (alts.length + (def ? 1 : 0)) + ' 个小号</span></span>' +
        '<button class="toggle ' + (enabled ? 'on' : '') + '" data-act="toggle-char" data-id="' + c.id + '"></button></div>';
      [main, def].concat(alts).filter(Boolean).forEach(function (a) {
        html += '<div class="item" data-act="open-profile" data-id="' + a.id + '">' +
          av(a, 'av36') + '<span class="t"><span>' + esc(a.name) + (a.protected ? ' <span class="badge gray">受保护</span>' : '') + '</span>' +
          '<span class="sub">@' + esc(a.handle) + ' · ' + (a.altType === 'main' ? '大号' : a.altType === 'default' ? '默认分身' : '小号') + (prefOf(a) ? ' · 有发帖偏好' : '') + '</span></span>' +
          '<button class="linkbtn" data-act="edit-account" data-id="' + a.id + '">编辑</button>' +
          (!a.protected ? '<button class="linkbtn" style="color:var(--danger)" data-act="del-alt" data-id="' + a.id + '">删除</button>' : '') +
          '</div>';
      });
      if ((st.alts || []).length < MAX_ALT) {
        html += '<button class="item" data-act="add-alt" data-id="' + c.id + '"><span class="t"><span>＋ 新建小号</span><span class="sub">设定方向与发帖偏好，AI 可协助生成人格</span></span></button>';
      }
      html += '</div>';
    });
    html += '<div class="settings-ttl">黑名单</div><div class="card">' +
      (blocked.length ? blocked.map(function (a) {
        return '<div class="item">' + av(a, 'av36') + '<span class="t"><span>' + esc(a.name) + '</span><span class="sub">@' + esc(a.handle) + '</span></span>' +
          '<button class="linkbtn" data-act="unblock" data-id="' + a.id + '">取消拉黑</button></div>';
      }).join('') : '<div class="empty" style="padding:24px">黑名单是空的。</div>') +
      '</div><div style="height:20px"></div></div>';
    $('#app').innerHTML = html;
  }

  /* ============================ 头像库 ============================ */
  function renderAvatars() {
    $('#app').innerHTML = head('头像库', { back: true, html: '<button class="iconbtn" data-act="add-avatar">' + I.plus + '</button>' }) +
      '<div class="scroll"><div class="pad small muted">上传后会压缩保存。给头像打标签，AI 生成小号 / NPC 时会按标签挑选。</div>' +
      (state.avatars.length ? '<div class="grid-av">' + state.avatars.map(function (a) {
        return '<button class="cell" data-act="edit-avatar" data-id="' + a.id + '"><img src="' + esc(a.data) + '" alt=""><div class="tags">' + esc((a.tags || []).join(' / ') || '无标签') + '</div></button>';
      }).join('') + '</div>' : '<div class="empty">头像库还是空的。<br><button class="btn sm" data-act="add-avatar">上传第一张</button></div>') +
      '<div style="height:20px"></div></div>';
  }

  /* ============================ 世界书 ============================ */
  function renderWorldBook() {
    var entries = (host.wbs || []).filter(function (w) { return w.type === 'entry'; });
    var all = state.settings.allWorldBooks;
    $('#app').innerHTML = head('默认世界书', { back: true }) +
      '<div class="scroll settings-scroll">' +
      '<div class="card"><div class="item"><span class="t"><span>使用全部世界书</span><span class="sub">关闭后可手动挑选</span></span>' +
      '<button class="toggle ' + (all ? 'on' : '') + '" data-act="wb-all"></button></div></div>' +
      '<div class="card"><h4>条目（' + entries.length + '）</h4>' +
      (entries.length ? entries.map(function (w) {
        var on = all || state.settings.worldBookIds.indexOf(w.id) >= 0;
        return '<div class="wb-entry" data-act="toggle-wb" data-id="' + w.id + '"><div class="check ' + (on ? 'on' : '') + '">✓</div>' +
          '<div class="t"><div>' + esc(w.name || '未命名') + '</div><div class="sub">' + esc(String(w.content || '').replace(/\s+/g, ' ').slice(0, 60)) + '</div></div></div>';
      }).join('') : '<div class="empty">宿主里还没有世界书条目。</div>') +
      '</div><div class="pad small muted">这里选择的世界书会作为固定上下文注入每一次 AI 调用（生成动态、评论、私信、小号人格）。</div></div>';
  }

  /* ============================ NPC 档案 ============================ */
  function renderNpcFile() {
    var s = S();
    var npcs = visibleAccounts('npc').filter(function (a) { return s.blocked.indexOf(a.id) < 0; });
    $('#app').innerHTML = head('NPC 档案（File）', { back: true }) +
      '<div class="scroll settings-scroll"><div class="pad small muted">在私信里把你的 IG ID 给 NPC 后，TA 会进入 File；这里可以改关系与备注。</div>' +
      (npcs.length ? '<div class="card">' + npcs.map(function (a) {
        var f = s.npcFile[a.id] || {};
        return '<div class="npcrow">' + openProfileBtn(a, 'av40') +
          '<div class="t" style="flex:1;min-width:0"><div class="row"><b>' + esc(a.name) + '</b>' + (f.inFile ? '<span class="badge">File</span>' : '') + '</div>' +
          '<div class="sub">@' + esc(a.handle) + ' · ' + esc(f.relationship || relLabel(s.affinity[a.id] || 0)) + ' · 亲密度 ' + (s.affinity[a.id] || 0) + '</div></div>' +
          '<button class="linkbtn" data-act="edit-npc" data-id="' + a.id + '">档案</button></div>';
      }).join('') + '</div>' : '<div class="empty">还没有 NPC。<br>去首页「认识新人」生成几个。</div>') + '</div>';
  }

  /* ============================ 弹层 ============================ */
  function openSheet(html, opts) {
    opts = opts || {};
    $('#layer').innerHTML = '<div class="overlay ' + (opts.center ? 'center' : '') + '"><div class="' + (opts.center ? 'modal' : 'sheet') + '">' + html + '</div></div>';
  }
  function closeLayer() { $('#layer').innerHTML = ''; }
  var confirmCb = null;
  function confirmBox(title, text, okText, cb) {
    confirmCb = cb;
    openSheet('<h3>' + esc(title) + '</h3><p>' + esc(text) + '</p><div class="modal-actions">' +
      '<button class="btn ghost" data-act="confirm-cancel">取消</button>' +
      '<button class="btn danger" data-act="confirm-ok">' + esc(okText || '确定') + '</button></div>', { center: true });
  }
  function val(sel) { var el = $(sel); return el ? el.value : ''; }
  function setVal(sel, v) { var el = $(sel); if (el) el.value = v == null ? '' : v; }
  function sheetHead(title, right) {
    return '<div class="sheet-head"><button class="closebtn" data-act="layer-close" title="关闭">' + I.close + '</button>' +
      '<b>' + esc(title) + '</b>' + (right || '') + '</div>';
  }

  function openCompose() {
    var u = activeUser();
    $('#layer').innerHTML = '<div class="compose">' +
      '<div class="compose-head"><button class="closebtn" data-act="layer-close" title="关闭">' + I.close + '</button><b>新动态</b>' +
      '<button class="btn sm" data-act="compose-send">发布</button></div>' +
      '<div class="compose-as">' + av(u, 'av24') + '<span>以 @' + esc(u.handle) + ' 发布</span></div>' +
      '<div class="compose-body"><textarea id="composeText" maxlength="600" placeholder="有什么新鲜事？"></textarea></div>' +
      '<div class="compose-foot"><span>发布后可能有路人点赞/评论</span><span id="composeCount">0/600</span></div></div>';
    setTimeout(function () { var el = $('#composeText'); if (el) el.focus(); }, 120);
  }

  function exitApp() {
    if (menuTapTimer) { clearTimeout(menuTapTimer); menuTapTimer = null; }
    try {
      if (window.UwU && typeof UwU.closeApp === 'function') { UwU.closeApp(); return; }
    } catch (e) { }
    try {
      var p = window.parent;
      if (p && p !== window && p.document) {
        var btn = p.document.querySelector('#store-app-runner-header .back-btn');
        if (btn) { btn.click(); return; }
        if (typeof p.switchScreen === 'function') { p.switchScreen('home-screen'); return; }
      }
    } catch (e) { }
    toast('请点左上角返回退出');
  }
  function handleMenuTap() {
    if (menuTapTimer) {
      clearTimeout(menuTapTimer);
      menuTapTimer = null;
      exitApp();
      return;
    }
    menuTapTimer = setTimeout(function () {
      menuTapTimer = null;
      openDrawer();
    }, 300);
  }
  function openDrawer() {
    var un = unreadNotifs();
    $('#layer').innerHTML = '<div class="overlay drawer-overlay">' +
      '<aside class="drawer">' +
      '<nav class="drawer-nav">' +
      '<button class="drawer-item" data-act="nav" data-v="notifs">' + I.bell + '<span>通知</span>' +
      (un ? '<span class="badge">' + (un > 99 ? '99+' : un) + '</span>' : '') + '</button>' +
      '<div class="drawer-sep"></div>' +
      '<button class="drawer-item" data-act="switch-sheet">' + I.user + '<span><b>账号管理</b><span class="sub">切换 / 新建账号</span></span></button>' +
      '<button class="drawer-item" data-act="open-chars">' + I.lock + '<span><b>角色与黑名单</b><span class="sub">角色接入 · 发帖偏好 · 黑名单</span></span></button>' +
      '<button class="drawer-item" data-act="open-settings">' + I.gear + '<span>设置</span></button>' +
      '</nav>' +
      '<div class="drawer-foot">v' + VERSION + '</div>' +
      '</aside></div>';
  }
  function openSwitch() {
    var users = Object.values(state.accounts).filter(function (a) { return a.kind === 'user'; });
    openSheet(sheetHead('切换账号') +
      users.map(function (a) {
        return '<button class="item" data-act="switch-user" data-id="' + a.id + '">' + av(a, 'av40') +
          '<span class="t"><span>' + esc(a.name) + '</span><span class="sub">@' + esc(a.handle) + '</span></span>' +
          (a.id === state.activeUserId ? '<span class="badge">当前</span>' : '') + '</button>';
      }).join('') +
      '<button class="item" data-act="new-user"><span class="t"><span>＋ 新建 X 账号</span><span class="sub">社交状态与当前账号互相独立</span></span></button>' +
      '<div style="height:10px"></div>');
  }
  function openRefresh() {
    openSheet(sheetHead('刷新动态') +
      '<button class="item" data-act="refresh-known"><span class="t"><span>看认识的人</span><span class="sub">刷新已关注 / 已认识角色的动态</span></span></button>' +
      '<button class="item" data-act="refresh-new"><span class="t"><span>认识新人</span><span class="sub">生成新的 NPC，偶尔出现角色小号</span></span></button>' +
      '<div class="pad small muted">「认识新人」会按当前账号的兴趣关键词生成人设。</div>');
  }
  function openPostMenu(postId) {
    var p = postById(postId); if (!p) return;
    var a = A(p.authorId), rel = relation(p.authorId);
    var mine = p.authorId === state.activeUserId;
    openSheet(sheetHead('动态') +
      (a ? itemRow({ act: 'open-profile', id: a.id, title: '查看 @' + a.handle, sub: a.name }) : '') +
      itemRow({ act: 'copy-post', id: p.id, title: '复制文字', sub: '复制这条动态的正文' }) +
      (mine ? itemRow({ act: 'expect-post', id: p.id, title: '期待TA回复和点赞', sub: '让 char 或 NPC 来回应你' }) : '') +
      (mine ? itemRow({ act: 'delete-post', id: p.id, title: '删除该帖子', sub: '从你的主页与时间线移除' }) : '') +
      (!mine && a ? itemRow({ act: rel.blocked ? 'unblock' : 'block', id: a.id, title: rel.blocked ? '取消拉黑' : '拉黑', sub: rel.blocked ? '' : '不再看到 TA 的动态与私信' }) : '') +
      '<div style="height:10px"></div>');
  }
  function openDmMenu(accId) {
    var a = A(accId); if (!a) return;
    var rel = relation(accId), s = S();
    var f = s.npcFile[accId] || {};
    openSheet(sheetHead('@' + a.handle) +
      '<div class="pad row">' + av(a, 'av48') + '<div class="t"><b>' + esc(a.name) + '</b><div class="sub">' + esc(a.bio || '') + '</div></div></div>' +
      itemRow({ act: 'open-profile', id: a.id, title: '查看主页', sub: '亲密度 ' + rel.affinity + '/100 · ' + relLabel(rel.affinity) }) +
      itemRow({ act: rel.following ? 'unfollow' : 'follow', id: a.id, title: rel.following ? '取消关注' : '关注', sub: rel.follower ? 'TA 关注了你' : '' }) +
      (a.kind !== 'user' && !f.igGiven ? itemRow({ act: 'give-ig', id: a.id, title: '把我的 IG ID 给 TA', sub: a.kind === 'char' ? '可能会掉马…' : 'TA 会进入 File 并加你 IG' }) : '') +
      (a.kind === 'char' && !knowsUserX(a) ? itemRow({ act: 'tell-x', id: a.id, title: '告诉TA我的 X 账号', sub: '主动告知后，TA 才会知道 @' + activeUser().handle }) : '') +
      (a.kind === 'npc' ? itemRow({ act: 'edit-npc', id: a.id, title: '编辑档案', sub: '关系 / 备注 / 亲密度' }) : '') +
      itemRow({ act: rel.blocked ? 'unblock' : 'block', id: a.id, title: rel.blocked ? '取消拉黑' : '拉黑' }) +
      '<div style="height:10px"></div>');
  }
  function openNewDm() {
    var s = S();
    var list = visibleAccounts().filter(function (a) { return a.kind !== 'user' && s.blocked.indexOf(a.id) < 0; });
    openSheet(sheetHead('发起私信') + (list.length ? list.map(function (a) {
      return '<button class="item" data-act="open-dm" data-id="' + a.id + '">' + av(a, 'av36') +
        '<span class="t"><span>' + esc(a.name) + '</span><span class="sub">@' + esc(a.handle) + '</span></span></button>';
    }).join('') : '<div class="empty">还没有可以私信的人。<br>先认识几个新人。</div>') + '<div style="height:10px"></div>');
  }

  function openEditProfile() {
    var u = activeUser();
    var coverStyle = u.cover ? ' style="background-image:url(\'' + esc(u.cover) + '\')"' : '';
    openSheet(sheetHead('编辑资料') +
      '<div class="field"><label>头像</label><input type="file" id="accAvatarFile" accept="image/*"><div class="hint">可选，自动压缩到 256px</div></div>' +
      '<div class="field"><label>名片背景</label>' +
      '<div class="cover-mini"' + coverStyle + '></div>' +
      '<input type="file" id="accCoverFile" accept="image/*">' +
      '<div class="hint">可选，自动裁剪成横图；不选则保留当前背景</div>' +
      '<input type="hidden" id="accCoverReset" value="">' +
      (u.cover ? '<div style="margin-top:8px"><button class="btn sm ghost" data-act="cover-default">恢复默认渐变</button></div>' : '') +
      '</div>' +
      '<div class="field"><label>名字</label><input id="accName" value="' + esc(u.name) + '"></div>' +
      '<div class="field"><label>Handle</label><input id="accHandle" value="' + esc(u.handle) + '"></div>' +
      '<div class="field"><label>简介</label><textarea id="accBio" rows="2">' + esc(u.bio || '') + '</textarea></div>' +
      '<div class="pad"><button class="btn block" data-act="save-user" data-id="' + u.id + '">保存</button></div>');
  }
  function openEditAccount(accId) {
    var a = A(accId); if (!a) return;
    var isChar = a.kind === 'char';
    var personaField = '';
    if (isChar) {
      if (a.altType === 'extra') {
        personaField = '<div class="field"><label>X 人设（仅这个小号）</label><textarea id="accPersona" rows="4" placeholder="这个小号在 X 上的性格与口吻">' + esc(a.persona || '') + '</textarea></div>';
      } else {
        personaField = '<div class="field"><label>X 人设（来自 404，实时同步）</label></div>';
      }
    }
    openSheet(sheetHead('编辑账号') +
      '<div class="pad row">' + av(a, 'av48') + '<div class="t"><b>' + esc(a.name) + '</b><div class="sub">@' + esc(a.handle) + ' · ' + (a.altType === 'main' ? '大号' : a.altType === 'default' ? '默认分身' : a.kind === 'npc' ? 'NPC' : '小号') + '</div></div></div>' +
      '<div class="field"><label>头像</label><input type="file" id="accAvatarFile" accept="image/*"><div class="hint">' + (a.kind === 'npc' ? '留空则保持当前头像' : '留空则保持当前头像') + '</div></div>' +
      '<div class="field"><label>名字</label><input id="accName" value="' + esc(a.name) + '"></div>' +
      '<div class="field"><label>Handle</label><input id="accHandle" value="' + esc(a.handle) + '"></div>' +
      '<div class="field"><label>简介</label><textarea id="accBio" rows="2">' + esc(a.bio || '') + '</textarea></div>' +
      personaField +
      (a.kind !== 'user' ? '<div class="field"><label>发帖偏好</label><textarea id="accPref" rows="3">' + esc(prefOf(a)) + '</textarea></div>' : '') +
      '<div class="pad"><button class="btn block" data-act="save-account" data-id="' + a.id + '">保存</button></div>');
  }
  function openAddAlt(cid) {
    var c = host.chars.find(function (x) { return String(x.id) === String(cid); });
    if (!c) return;
    openSheet(sheetHead('新建小号 · ' + (c.remarkName || c.realName)) +
      '<div class="field"><label>小号方向（给 AI 的提示，可留空）</label><input id="altHint" placeholder="例：情侣日常博主 / 深夜emo / 装陌生人"></div>' +
      '<div class="field"><label>名字</label><input id="altName" placeholder="留空可让 AI 生成"></div>' +
      '<div class="field"><label>Handle</label><input id="altHandle" placeholder="可留空"></div>' +
      '<div class="field"><label>简介</label><input id="altBio" placeholder="可留空"></div>' +
      '<div class="field"><label>小号人设</label><textarea id="altPersona" rows="3" placeholder="可留空，让 AI 写"></textarea></div>' +
      '<div class="field"><label>发帖偏好</label><textarea id="altPref" rows="3"></textarea></div>' +
      '<div class="pad row" style="gap:8px"><button class="btn ghost" style="flex:1" data-act="ai-alt" data-id="' + cid + '">AI 帮我写</button>' +
      '<button class="btn" style="flex:1" data-act="create-alt" data-id="' + cid + '">创建小号</button></div>' +
      '<div class="pad small muted">小号属于当前 X 账号（@' + esc(activeUser().handle) + '），切换到别的账号看不到它。</div>');
  }
  function openAddAvatar() {
    openSheet(sheetHead('添加头像') +
      '<div class="field"><label>图片</label><input type="file" id="avFile" accept="image/*"></div>' +
      '<div class="field"><label>标签（逗号分隔）</label><input id="avTags" placeholder="例：清冷, 男生, 夜景"></div>' +
      '<div class="pad"><button class="btn block" data-act="save-avatar">保存到头像库</button></div>');
  }
  function openEditAvatar(id) {
    var a = state.avatars.find(function (x) { return x.id === id; }); if (!a) return;
    openSheet(sheetHead('头像标签') +
      '<div class="pad"><img src="' + esc(a.data) + '" style="width:100%;border-radius:14px"></div>' +
      '<div class="field"><label>标签（逗号分隔）</label><input id="avTags" value="' + esc((a.tags || []).join(', ')) + '"></div>' +
      '<div class="pad row" style="gap:8px"><button class="btn ghost" style="flex:1" data-act="del-avatar" data-id="' + a.id + '">删除</button>' +
      '<button class="btn" style="flex:1" data-act="save-avatar" data-id="' + a.id + '">保存标签</button></div>');
  }
  function openNpcMeta(accId) {
    var a = A(accId); if (!a) return;
    var f = S().npcFile[accId] || {};
    var rels = ['陌生', '眼熟', '朋友', '密友', '恋人', '暧昧', '心理疏导', '树洞'];
    openSheet(sheetHead('NPC 档案') +
      '<div class="pad row">' + av(a, 'av48') + '<div class="t"><b>' + esc(a.name) + '</b><div class="sub">@' + esc(a.handle) + '</div></div></div>' +
      '<div class="field"><label>关系</label><select id="npcRel">' + rels.map(function (r) { return '<option' + ((f.relationship || '') === r ? ' selected' : '') + '>' + r + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label>亲密度（0-100）</label><input id="npcAff" type="number" min="0" max="100" value="' + (S().affinity[accId] || 0) + '"></div>' +
      '<div class="field"><label>私下备注</label><textarea id="npcNote" rows="4" placeholder="只有你能看到">' + esc(f.note || '') + '</textarea></div>' +
      '<div class="field"><label>是否在 File 中</label><button class="toggle ' + (f.inFile ? 'on' : '') + '" data-act="npc-infile" data-id="' + accId + '"></button></div>' +
      '<div class="pad"><button class="btn block" data-act="save-npc" data-id="' + accId + '">保存档案</button></div>');
  }
  function openBlacklist() {
    var s = S();
    var list = s.blocked.map(A).filter(Boolean);
    openSheet(sheetHead('黑名单') + (list.length ? list.map(function (a) {
      return '<div class="item">' + av(a, 'av36') + '<span class="t"><span>' + esc(a.name) + '</span><span class="sub">@' + esc(a.handle) + '</span></span>' +
        '<button class="linkbtn" data-act="unblock" data-id="' + a.id + '">取消拉黑</button></div>';
    }).join('') : '<div class="empty">黑名单是空的。</div>') + '<div style="height:10px"></div>');
  }
  function openNewUser() {
    openSheet(sheetHead('新建 X 账号') +
      '<div class="field"><label>名字</label><input id="newName" placeholder="这个账号的网名"></div>' +
      '<div class="field"><label>Handle（可留空）</label><input id="newHandle" placeholder="英文、数字、下划线"></div>' +
      '<div class="field"><label>简介</label><textarea id="newBio" rows="2" placeholder="随便写点"></textarea></div>' +
      '<div class="pad"><button class="btn block" data-act="save-new-user">创建并切换</button></div>');
  }

  /* ============================ 图片 ============================ */
  function readImage(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onerror = reject;
      fr.onload = function () {
        var img = new Image();
        img.onerror = reject;
        img.onload = function () {
          var scale = Math.min(1, 256 / Math.max(img.width, img.height));
          var c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(img.width * scale));
          c.height = Math.max(1, Math.round(img.height * scale));
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', 0.82));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  function readCoverImage(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onerror = reject;
      fr.onload = function () {
        var img = new Image();
        img.onerror = reject;
        img.onload = function () {
          var tw = 1080, th = 470;
          var scale = Math.max(tw / img.width, th / img.height);
          var sw = tw / scale, sh = th / scale;
          var sx = (img.width - sw) / 2, sy = (img.height - sh) / 2;
          var c = document.createElement('canvas');
          c.width = tw; c.height = th;
          c.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, tw, th);
          resolve(c.toDataURL('image/jpeg', 0.82));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  function parseTags(v) {
    return String(v || '').split(/[,，\s]+/).map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 8);
  }
  function copyText(t) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(function () { toast('已复制'); }, function () { toast('复制失败'); });
    } else {
      var ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); toast('已复制'); } catch (e) { toast('复制失败'); }
      ta.remove();
    }
  }

  /* ============================ 保存动作 ============================ */
  async function saveUser(id) {
    var u = A(id); if (!u) return;
    var name = val('#accName').trim() || u.name;
    var handle = val('#accHandle').trim().replace(/[^a-zA-Z0-9_]/g, '');
    u.name = name;
    if (handle && handle !== u.handle) u.handle = uniqHandle(handle, u.id);
    u.bio = val('#accBio').trim();
    var f = $('#accAvatarFile');
    if (f && f.files && f.files[0]) { try { u.avatar = await readImage(f.files[0]); } catch (e) { toast('头像读取失败'); } }
    var cf = $('#accCoverFile');
    if (cf && cf.files && cf.files[0]) {
      try { u.cover = await readCoverImage(cf.files[0]); } catch (e) { toast('名片背景读取失败'); }
    } else if ($('#accCoverReset') && $('#accCoverReset').value === '1') {
      u.cover = '';
    }
    save(); closeLayer(); render(); toast('资料已保存');
  }
  async function saveAccount(id) {
    var a = A(id); if (!a) return;
    var name = val('#accName').trim() || a.name;
    var handle = val('#accHandle').trim().replace(/[^a-zA-Z0-9_]/g, '');
    a.name = name;
    if (handle && handle !== a.handle) a.handle = uniqHandle(handle, a.id);
    a.bio = val('#accBio').trim();
    if (a.kind === 'char' && a.altType === 'extra') a.persona = val('#accPersona').trim();
    if (a.kind !== 'user') a.pref = val('#accPref').trim();
    var f = $('#accAvatarFile');
    if (f && f.files && f.files[0]) { try { a.avatar = await readImage(f.files[0]); } catch (e) { toast('头像读取失败'); } }
    save(); closeLayer(); render(); toast('账号已更新');
  }
  function createAlt(cid) {
    var c = host.chars.find(function (x) { return String(x.id) === String(cid); }); if (!c) return;
    var st = state.charState[String(cid)];
    if (!st) { st = { enabled: true, alts: [] }; state.charState[String(cid)] = st; }
    if ((st.alts || []).length >= MAX_ALT) return toast('最多只能有 ' + MAX_ALT + ' 个小号');
    var name = val('#altName').trim() || val('#altHint').trim();
    if (!name) return toast('先填个名字，或点「AI 帮我写」');
    var id = 'ca_' + String(cid).replace(/[^\w-]/g, '').slice(0, 8) + '_' + Math.random().toString(36).slice(2, 6);
    var handle = val('#altHandle').trim();
    state.accounts[id] = {
      id: id, kind: 'char', charId: String(cid), altType: 'extra', ownerUserId: state.activeUserId,
      name: name.slice(0, 24), handle: uniqHandle(handle || name, id),
      avatar: avatarFor(name, id), bio: val('#altBio').trim().slice(0, 90),
      persona: val('#altPersona').trim() || ('这是' + (c.remarkName || c.realName) + '在X上的小号，' + (val('#altHint').trim() || '隐藏身份')),
      pref: val('#altPref').trim(), secret: '', protected: false, tags: [], createdAt: Date.now()
    };
    st.alts = st.alts || []; st.alts.push(id);
    save(); closeLayer(); ui.view = 'chars'; render(); toast('小号已创建');
  }
  async function aiFillAlt(cid) {
    var c = host.chars.find(function (x) { return String(x.id) === String(cid); }); if (!c) return;
    try {
      toast('正在生成小号人格…');
      var d = await genAltPersona(c, val('#altHint').trim(), val('#altPref').trim());
      if (!val('#altName').trim()) setVal('#altName', d.name || '');
      if (!val('#altHandle').trim()) setVal('#altHandle', d.handle || '');
      if (!val('#altBio').trim()) setVal('#altBio', d.bio || '');
      setVal('#altPersona', d.persona || '');
      toast('已生成，可修改后创建');
    } catch (e) { toast('生成失败：' + e.message); }
  }
  async function saveAvatar(id) {
    var tags = parseTags(val('#avTags'));
    if (id) {
      var a = state.avatars.find(function (x) { return x.id === id; });
      if (!a) return;
      a.tags = tags; save(); closeLayer(); render(); return toast('标签已保存');
    }
    var f = $('#avFile');
    if (!f || !f.files || !f.files[0]) return toast('先选择一张图片');
    try {
      var data = await readImage(f.files[0]);
      state.avatars.push({ id: uid('av'), data: data, tags: tags });
      save(); closeLayer(); render(); toast('已加入头像库');
    } catch (e) { toast('图片读取失败'); }
  }
  function saveNpc(id) {
    var s = S();
    var cur = s.npcFile[id] || {};
    s.npcFile[id] = Object.assign({ inFile: true, relationship: '陌生', note: '' }, cur, {
      relationship: val('#npcRel') || '陌生',
      note: val('#npcNote').trim()
    });
    s.affinity[id] = clamp(parseInt(val('#npcAff'), 10) || 0, 0, 100);
    save(); closeLayer(); render(); toast('档案已保存');
  }
  function saveNewUser() {
    var name = val('#newName').trim() || '新账号';
    var id = 'u_' + Math.random().toString(36).slice(2, 8);
    state.accounts[id] = {
      id: id, kind: 'user', name: name.slice(0, 20),
      handle: uniqHandle(val('#newHandle') || name, id),
      avatar: avatarFor(name, id), bio: val('#newBio').trim() || '只是在 X 上看看。',
      createdAt: Date.now()
    };
    state.activeUserId = id;
    S(); save(); closeLayer(); ui.view = 'home'; ui.tab = 'home'; render();
    toast('已切换到 @' + state.accounts[id].handle);
  }

  /* ============================ 事件 ============================ */
  function handleClick(e) {
    var ov = e.target.closest('.overlay');
    if (ov && !e.target.closest('.sheet') && !e.target.closest('.modal') && !e.target.closest('.drawer')) { closeLayer(); return; }
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var act = el.getAttribute('data-act');
    var id = el.getAttribute('data-id');
    try {
      switch (act) {
        case 'layer-close': closeLayer(); break;
        case 'confirm-ok': { var cb = confirmCb; confirmCb = null; closeLayer(); if (cb) cb(); break; }
        case 'confirm-cancel': confirmCb = null; closeLayer(); break;

        case 'nav': {
          closeLayer();
          var v = el.getAttribute('data-v');
          if (v === 'home') { ui.view = 'home'; ui.tab = 'home'; }
          else if (v === 'profile') { ui.profile = state.activeUserId; ui.view = 'profile'; ui.tab = 'profile'; }
          else { ui.view = v; ui.tab = v; }
          render(); break;
        }
        case 'back': {
          if (ui.view === 'dm') { ui.view = 'messages'; ui.tab = 'messages'; }
          else if (ui.view === 'thread' || ui.view === 'profile' || ui.view === 'notifs' || ui.view === 'messages' || ui.view === 'settings' || ui.view === 'chars') { ui.view = 'home'; ui.tab = 'home'; }
          else if (ui.view === 'avatars' || ui.view === 'worldbook' || ui.view === 'npcs') { ui.view = 'settings'; }
          else { ui.view = 'home'; ui.tab = 'home'; }
          render(); break;
        }
        case 'feed': ui.feed = el.getAttribute('data-v'); render(); break;
        case 'open-post': ui.thread = id; ui.view = 'thread'; render(); break;
        case 'open-profile': ui.profile = id; ui.view = 'profile'; render(); break;
        case 'open-dm': closeLayer(); openDm(id); break;
        case 'follow': follow(id); break;
        case 'unfollow': unfollow(id); break;
        case 'like': toggleLike(id); break;
        case 'repost': toggleRepost(id); break;
        case 'share': { var p = postById(id); if (p) copyText(p.text); break; }
        case 'copy-post': { var pp = postById(id); if (pp) copyText(pp.text); closeLayer(); break; }
        case 'comment-send': { var t = val('#cmtInput').trim(); if (!t) { toast('写点什么'); break; } commentAsMe(id, t); break; }
        case 'compose': openCompose(); break;
        case 'compose-send': { var ct = val('#composeText').trim(); if (!ct) { toast('写点什么'); break; } publishPost(ct); break; }
        case 'open-drawer': handleMenuTap(); break;
        case 'switch-sheet': openSwitch(); break;
        case 'switch-user': { state.activeUserId = id; S(); save(); closeLayer(); ui.view = 'home'; ui.tab = 'home'; ui.profile = null; render(); toast('已切换账号'); break; }
        case 'new-user': openNewUser(); break;
        case 'save-new-user': saveNewUser(); break;
        case 'refresh-sheet': openRefresh(); break;
        case 'refresh-known': closeLayer(); refreshKnown(); break;
        case 'refresh-new': closeLayer(); refreshNew(); break;
        case 'cover-default': {
          var reset = $('#accCoverReset'); if (reset) reset.value = '1';
          var mini = $('.cover-mini'); if (mini) mini.style.display = 'none';
          toast('保存后恢复默认渐变');
          break;
        }
        case 'post-menu': openPostMenu(id); break;
        case 'expect-post': closeLayer(); expectPost(id); break;
        case 'delete-post': {
          confirmBox('删除这条帖子？', '删除后无法恢复。', '删除', function () { deletePost(id); });
          break;
        }
        case 'expect-reply': {
          var pid = el.getAttribute('data-post');
          expectCommentReply(pid, id);
          break;
        }
        case 'dm-menu': openDmMenu(id); break;
        case 'edit-profile': openEditProfile(); break;
        case 'nick-edit': {
          var nowTs = Date.now();
          if (nickTapAt && nowTs - nickTapAt < 450) {
            nickTapAt = 0;
            openEditProfile();
          } else {
            nickTapAt = nowTs;
            toast('再点一次昵称可编辑资料');
          }
          break;
        }
        case 'edit-account': openEditAccount(id); break;
        case 'save-user': saveUser(id); break;
        case 'save-account': saveAccount(id); break;
        case 'open-settings': closeLayer(); ui.view = 'settings'; render(); break;
        case 'open-chars': {
          closeLayer(); ui.view = 'chars'; render();
          toast('正在同步宿主数据…');
          loadHost().then(function () {
            ensureCharAccounts(); upsertUser(); save();
            if (ui.view === 'chars') render();
            toast('已同步宿主数据');
          }).catch(function (err) { toast('同步失败：' + err.message); });
          break;
        }
        case 'open-avatars': closeLayer(); ui.view = 'avatars'; render(); break;
        case 'open-worldbook': closeLayer(); ui.view = 'worldbook'; render(); break;
        case 'open-npcs': closeLayer(); ui.view = 'npcs'; render(); break;
        case 'open-blacklist': closeLayer(); ui.view = 'chars'; render(); break;
        case 'toggle-char': {
          var st = state.charState[String(id)] || { enabled: true, alts: [] };
          st.enabled = st.enabled === false;
          state.charState[String(id)] = st; save(); render(); break;
        }
        case 'theme-toggle': state.theme = state.theme === 'dark' ? 'light' : 'dark'; save(); render(); break;
        case 'toggle-delay': state.settings.replyDelay = !state.settings.replyDelay; save(); render(); break;
        case 'wb-all': state.settings.allWorldBooks = !state.settings.allWorldBooks;
          if (state.settings.allWorldBooks) state.settings.worldBookIds = [];
          save(); render(); break;
        case 'toggle-wb': {
          var ents = (host.wbs || []).filter(function (w) { return w.type === 'entry'; });
          var ids = state.settings.allWorldBooks ? ents.map(function (w) { return w.id; }) : state.settings.worldBookIds.slice();
          var ix = ids.indexOf(id);
          if (ix >= 0) ids.splice(ix, 1); else ids.push(id);
          state.settings.worldBookIds = ids;
          state.settings.allWorldBooks = ids.length === ents.length;
          save(); render(); break;
        }
        case 'add-interest': {
          var kw = val('#interestInput').trim();
          if (!kw) break;
          if (S().interests.indexOf(kw) < 0) S().interests.push(kw);
          save(); render(); break;
        }
        case 'del-interest': { S().interests = S().interests.filter(function (x) { return x !== id; }); save(); render(); break; }
        case 'add-alt': openAddAlt(id); break;
        case 'ai-alt': aiFillAlt(id); break;
        case 'create-alt': createAlt(id); break;
        case 'del-alt': {
          confirmBox('删除小号？', '这个小号的账号与设定会从当前 X 账号中移除。', '删除', function () {
            var a = A(id);
            if (a && a.charId && state.charState[String(a.charId)]) {
              state.charState[String(a.charId)].alts = (state.charState[String(a.charId)].alts || []).filter(function (x) { return x !== id; });
            }
            delete state.accounts[id];
            save(); render(); toast('已删除');
          });
          break;
        }
        case 'add-avatar': openAddAvatar(); break;
        case 'edit-avatar': openEditAvatar(id); break;
        case 'save-avatar': saveAvatar(id); break;
        case 'del-avatar': {
          confirmBox('删除这张头像？', 'AI 之后不会再使用它。', '删除', function () {
            state.avatars = state.avatars.filter(function (x) { return x.id !== id; });
            save(); closeLayer(); render();
          });
          break;
        }
        case 'edit-npc': openNpcMeta(id); break;
        case 'save-npc': saveNpc(id); break;
        case 'npc-infile': {
          var f = S().npcFile[id] || {}; f.inFile = !f.inFile; S().npcFile[id] = f; save();
          openNpcMeta(id); break;
        }
        case 'give-ig': closeLayer(); giveIg(id); break;
        case 'tell-x': tellX(id); break;
        case 'new-dm': openNewDm(); break;
        case 'clear-notifs': S().notifs = []; save(); render(); break;
        case 'resync': {
          closeLayer(); toast('正在同步…');
          loadHost().then(function () { ensureCharAccounts(); upsertUser(); save(); render(); toast('已同步'); }).catch(function (err) { toast('同步失败：' + err.message); });
          break;
        }
        case 'retry': boot(); break;
        case 'unblock': unblock(id); closeLayer(); break;
        case 'block': closeLayer(); block(id); break;
        case 'dm-send': { var dt = val('#dmInput').trim(); if (!dt) break; sendDm(dt); break; }
        case 'dm-refresh': refreshDm(id); break;
        default: break;
      }
    } catch (err) {
      console.error('[X] action failed', act, err);
      toast('操作失败：' + err.message);
    }
  }

  function handleChange(e) {
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var act = el.getAttribute('data-act');
    if (act === 'sleep-start') { state.settings.sleepStart = Number(el.value); save(); render(); }
    if (act === 'sleep-end') { state.settings.sleepEnd = Number(el.value); save(); render(); }
    if (act === 'accPersonaSel') {
      var p = (host.personas || []).find(function (x) { return x.id === el.value; });
      setVal('#accPersona', p ? String(p.persona || '') : '');
    }
  }
  function handleInput(e) {
    if (e.target.id === 'composeText') {
      var c = $('#composeCount'); if (c) c.textContent = e.target.value.length + '/600';
    }
  }

  function bindEvents() {
    document.addEventListener('click', handleClick);
    document.addEventListener('change', handleChange);
    document.addEventListener('input', handleInput);
  }

  /* ============================ 启动 ============================ */
  async function boot() {
    state = loadState();
    document.documentElement.dataset.theme = state.theme || 'dark';
    if (!state.avatars.length) {
      state.avatars.push({ id: uid('av'), data: avatarFor('光', 'a'), tags: ['清冷', '风景'] });
      state.avatars.push({ id: uid('av'), data: avatarFor('夜', 'b'), tags: ['夜色', '男生'] });
      state.avatars.push({ id: uid('av'), data: avatarFor('糖', 'c'), tags: ['甜', '女生'] });
      save();
    }
    try {
      await loadHost();
    } catch (err) {
      $('#app').innerHTML = '<div class="empty" style="margin-top:70px">无法连接 UwU 小手机<br><span class="small">' + esc(err.message) + '</span><br><br><button class="btn sm" data-act="retry">重试</button></div>';
      return;
    }
    upsertUser();
    ensureCharAccounts();
    if (!ui.profile) ui.profile = state.activeUserId;
    render();
    setInterval(function () { processPending(); }, 20000);
    setTimeout(processPending, 1500);
  }

  window.__XAPP = { state: function () { return state; }, refreshKnown: refreshKnown, refreshNew: refreshNew, render: render, openSheet: openSheet, closeLayer: closeLayer };
  bindEvents();
  boot();


})();
